# 电子鼻牛肉新鲜度检测台（v2）

三步完成一次检测：**提交数据**（上传 CSV / Excel、从 Excel 粘贴、或用示例）→ **数据核验**（先确认识别结果，不跑模型）→ **判定结果**（直接回答「这块牛肉新鲜吗？」，并给出每个 60 分钟窗口的判定、置信度、概率变化和漂移补偿效果）。

视觉为明亮极繁风格（肉铺海报 + 检疫章），说明见设计规范第 5 节。

- 前端：Next.js 16（App Router）+ React 19 + TypeScript + Tailwind CSS v4
- 后端：FastAPI + onnxruntime（复用交付包的 `model.onnx`，逻辑与 `inference_onnx.py` 一致）
- 两个推理引擎结果一致：服务器（主路径，支持 Excel）和浏览器内 onnxruntime-web（后端不可用时自动切换，仅 CSV）

文档：[需求规格](docs/01-需求规格.md) ｜ [架构与接口](docs/02-架构与接口.md) ｜ [设计规范](docs/03-设计规范.md)

## 快速开始（本机开发）

需要 Python 3.10+ 和 Node.js 20.9+（推荐 22）。开两个终端：

**终端 1：后端**

```bash
cd backend
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload --port 8000
```

打开 <http://127.0.0.1:8000/docs> 可看到交互式接口文档。

**终端 2：前端**

```bash
cd frontend
npm install
npm run dev
```

打开 <http://localhost:3000> ，点「载入示例数据」→「开始判定」。

> 前端通过 Next.js 把 `/api/*` 转发到 `BACKEND_URL`（默认 `http://127.0.0.1:8000`）。后端没启动时页面会自动改用浏览器推理，照样能演示。

## 用 Docker 一键运行

```bash
docker compose up --build
```

然后打开 <http://localhost:3000> 。

## 测试与检查

```bash
# 后端：21 个测试，含与 sample_predictions.csv 的逐项一致性校验
cd backend && pytest -q && ruff check .

# 前端：11 个测试，含浏览器引擎与参考结果、服务器结果（判定与核验）的一致性校验
cd frontend && npm run lint && npm run typecheck && npm test && npm run build
```

`.github/workflows/ci.yml` 在每次推送时自动跑以上全部检查。

## 目录

```
backend/
  app/            FastAPI：main 路由、parsing 读表校验、inference ONNX 会话、analysis 滑窗
  assets/         model.onnx、model_meta.json、metrics.json（真实评估指标）、示例数据
  tests/          pytest
frontend/
  src/app/        页面：/ 分析台，/model 模型说明
  src/components/ 界面组件；charts/ 为自绘 SVG 时间轴与补偿小图
  src/lib/engine/ 推理引擎：server.ts、browser.ts、parse-table.ts、windowing.ts
  src/store/      zustand 状态
  public/         model.onnx、示例 CSV、评估图；ort/ 由 npm install 自动生成
docs/             需求、架构、设计、任务清单
```

## 换模型

模型重新训练后，替换以下文件即可，无需改代码（输入输出签名不变的前提下）：

1. `backend/assets/model_beef/model.onnx` 和 `model_meta.json`
2. `frontend/public/models/model.onnx`（浏览器引擎用）
3. 指标变化时同步更新 `backend/assets/model_beef/metrics.json` 和 `frontend/src/data/metrics.json`（测试会检查两份是否一致）
4. 重新生成前端契约测试用的样例：`cd backend && python -c "from fastapi.testclient import TestClient; from app.main import app; import json; c=TestClient(app); c.__enter__(); [json.dump(c.post(f'/api/{k}/sample').json(), open(f'../frontend/src/test/fixtures/sample-{k}.server.json','w'), ensure_ascii=False) for k in ('analyze','inspect')]"`，并用新模型的 `inference_onnx.py` 输出替换 `sample_predictions.csv`

## 常见问题

- **`npm install` 报 `Cannot read properties of null (reading 'edgesOut')`**：这是 npm 10.9 的已知问题，项目已在 `frontend/.npmrc` 设置 `legacy-peer-deps=true` 规避。若仍报错，升级 npm（`npm i -g npm@11`）后重试。
- **浏览器引擎首次较慢**：首次需要下载约 14 MB 的 wasm 运行时（gzip 后约 3–4 MB），之后走缓存。只有切换到浏览器引擎时才会下载，不影响首屏。
- **Excel 文件能否用浏览器引擎**：不能，请用服务器引擎，或在 Excel 里另存为 CSV。

## 声明

研究演示，不作为食品安全判定依据。数据集：Wijaya, D. R. (2022). Dataset for electronic nose from various beef cuts. Harvard Dataverse, V2. <https://doi.org/10.7910/DVN/XNFVTS> （CC0 1.0）。
