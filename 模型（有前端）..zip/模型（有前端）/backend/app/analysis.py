"""滑窗分析：与 inference_onnx.py 的规则逐项一致（基线 20 行，窗口 60，row_end 1 起计）。"""

from __future__ import annotations

import time

import numpy as np

from .inference import ModelService
from .parsing import ParsedTable
from .schemas import (
    Agreement,
    AnalysisResult,
    InspectResult,
    Latest,
    ModelParams,
    Series,
    SourceInfo,
    Summary,
    Truth,
    TruthSegment,
    WindowResult,
)


def window_ends(n_rows: int, baseline_len: int, win: int, stride: int) -> np.ndarray:
    """窗口结束行（0 起计），与参考脚本 np.arange(bl + win - 1, len(sig), stride) 相同。"""
    return np.arange(baseline_len + win - 1, n_rows, stride)


def _segments(labels: list[int | None], cuts: list[str | None] | None) -> list[TruthSegment]:
    segs: list[TruthSegment] = []
    start = 0
    for i in range(1, len(labels) + 1):
        boundary = (
            i == len(labels)
            or labels[i] != labels[start]
            or (cuts is not None and cuts[i] != cuts[start])
        )
        if boundary:
            segs.append(
                TruthSegment(
                    start_row=start + 1,
                    end_row=i,
                    label=labels[start],
                    cut=cuts[start] if cuts is not None else None,
                )
            )
            start = i
    return segs


def analyze(
    table: ParsedTable,
    model: ModelService,
    *,
    file_name: str,
    stride: int,
    include_compensated: bool,
    batch_size: int = 256,
) -> AnalysisResult:
    t0 = time.perf_counter()
    meta = model.meta
    sig = table.signals
    n = sig.shape[0]
    ends = window_ends(n, meta.baseline_len, meta.win, stride)
    windows = np.stack([sig[e - meta.win + 1 : e + 1] for e in ends]).astype(np.float32)
    probs, comp = model.run(windows, sig[: meta.baseline_len], batch_size=batch_size)

    preds = probs.argmax(1)
    conf = probs.max(1)
    mins = table.minutes
    labels = table.labels

    win_results: list[WindowResult] = []
    for k, e in enumerate(ends):
        s = int(e) - meta.win + 1
        truth = labels[int(e)] if labels is not None else None
        win_results.append(
            WindowResult(
                index=k,
                start_row=s + 1,
                end_row=int(e) + 1,
                minute_start=float(mins[s]),
                minute_end=float(mins[int(e)]),
                pred=int(preds[k]),
                confidence=round(float(conf[k]), 6),
                probs=[round(float(p), 6) for p in probs[k]],
                truth=truth,
            )
        )

    n_classes = len(meta.class_names)
    counts = [int((preds == c).sum()) for c in range(n_classes)]
    first_minute: list[float | None] = []
    for c in range(n_classes):
        idx = np.flatnonzero(preds == c)
        first_minute.append(float(mins[int(ends[idx[0]])]) if idx.size else None)

    agreement = None
    if labels is not None:
        scored = [w for w in win_results if w.truth is not None]
        agreement = Agreement(matched=sum(w.pred == w.truth for w in scored), total=len(scored))

    truth = None
    if labels is not None:
        truth = Truth(labels=labels, segments=_segments(labels, table.cuts))

    compensated = None
    if include_compensated:
        # [B, win, S] → [B, S, win]，方便前端按传感器画小图
        compensated = np.round(comp.transpose(0, 2, 1).astype(np.float64), 3).tolist()

    warnings = list(table.warnings)
    tail = (n - meta.baseline_len - meta.win) % stride
    if tail:
        warnings.append(f"最后 {tail} 行不足一个步长，未单独生成窗口。")

    return AnalysisResult(
        source=SourceInfo(
            file_name=file_name, sheet=table.sheet, sheets=table.sheets, rows=n, engine="server"
        ),
        model=ModelParams(
            sensors=meta.sensors,
            class_names=meta.class_names,
            win=meta.win,
            baseline_len=meta.baseline_len,
            stride=stride,
        ),
        series=Series(
            minute=mins.tolist(),
            values=np.round(sig.T.astype(np.float64), 4).tolist(),
        ),
        truth=truth,
        windows=win_results,
        compensated=compensated,
        summary=Summary(
            counts=counts,
            first_minute=first_minute,
            agreement=agreement,
            latest=Latest(pred=int(preds[-1]), confidence=round(float(conf[-1]), 6)),
        ),
        warnings=warnings,
        elapsed_ms=round((time.perf_counter() - t0) * 1000, 2),
    )


def inspect(
    table: ParsedTable, model: ModelService, *, file_name: str, stride: int
) -> InspectResult:
    meta = model.meta
    n = table.signals.shape[0]
    ends = window_ends(n, meta.baseline_len, meta.win, stride)
    mins = table.minutes
    truth_counts = None
    if table.labels is not None:
        truth_counts = [
            sum(1 for v in table.labels if v == c) for c in range(len(meta.class_names))
        ]
    return InspectResult(
        file_name=file_name,
        sheet=table.sheet,
        sheets=table.sheets,
        rows=n,
        columns=table.columns or [],
        sensors=meta.sensors,
        minute_column=table.minute_column,
        label_column=table.label_column,
        cut_column=table.cut_column,
        duration_minutes=float(mins[-1] - mins[0] + 1),
        baseline_len=meta.baseline_len,
        win=meta.win,
        stride=stride,
        n_windows=len(ends),
        first_judgement_minute=float(mins[meta.baseline_len + meta.win - 1]),
        truth_counts=truth_counts,
        preview=np.round(table.signals[:5].astype(np.float64), 4).tolist(),
        warnings=list(table.warnings),
    )
