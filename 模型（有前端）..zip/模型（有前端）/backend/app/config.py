"""运行配置：全部来自环境变量，带安全默认值。"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = BASE_DIR / "assets"


def _split(value: str) -> list[str]:
    return [v.strip() for v in value.split(",") if v.strip()]


@dataclass(frozen=True)
class Settings:
    model_path: Path = Path(os.getenv("MODEL_PATH", ASSETS_DIR / "model_beef" / "model.onnx"))
    meta_path: Path = Path(
        os.getenv("MODEL_META_PATH", ASSETS_DIR / "model_beef" / "model_meta.json")
    )
    metrics_path: Path = Path(
        os.getenv("MODEL_METRICS_PATH", ASSETS_DIR / "model_beef" / "metrics.json")
    )
    sample_path: Path = Path(
        os.getenv("SAMPLE_PATH", ASSETS_DIR / "samples" / "sample_beef_input.csv")
    )
    max_upload_bytes: int = int(os.getenv("MAX_UPLOAD_MB", "10")) * 1024 * 1024
    max_rows: int = int(os.getenv("MAX_ROWS", "20000"))
    default_stride: int = int(os.getenv("DEFAULT_STRIDE", "10"))
    batch_size: int = int(os.getenv("INFER_BATCH_SIZE", "256"))
    allowed_origins: list[str] = field(
        default_factory=lambda: _split(
            os.getenv("ALLOWED_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000")
        )
    )


settings = Settings()
