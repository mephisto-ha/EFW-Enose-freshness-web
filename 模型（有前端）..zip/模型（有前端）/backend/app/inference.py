"""ONNX 推理：启动时加载一次；InferenceSession.run 线程安全，可被并发请求共用。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import onnxruntime as ort

from .errors import AppError


@dataclass(frozen=True)
class ModelMeta:
    task: str
    sensors: list[str]
    class_names: list[str]
    win: int
    baseline_len: int
    temperature: float
    n_parameters: int

    @property
    def n_sensors(self) -> int:
        return len(self.sensors)

    @property
    def min_rows(self) -> int:
        return self.baseline_len + self.win


class ModelService:
    def __init__(self, model_path: Path, meta_path: Path, metrics_path: Path) -> None:
        raw = json.loads(Path(meta_path).read_text(encoding="utf-8"))
        self.meta = ModelMeta(
            task=raw["task"],
            sensors=list(raw["sensors"]),
            class_names=list(raw["class_names"]),
            win=int(raw["win"]),
            baseline_len=int(raw["baseline_len"]),
            temperature=float(raw["temperature"]),
            n_parameters=int(raw["n_parameters"]),
        )
        self.metrics: dict[str, Any] = json.loads(Path(metrics_path).read_text(encoding="utf-8"))
        opts = ort.SessionOptions()
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.session = ort.InferenceSession(
            str(model_path), sess_options=opts, providers=["CPUExecutionProvider"]
        )
        self.input_names = [i.name for i in self.session.get_inputs()]
        self.output_names = [o.name for o in self.session.get_outputs()]
        expected = {"window_raw", "baseline_raw"}
        if set(self.input_names) != expected:
            raise RuntimeError(f"模型输入应为 {expected}，实际为 {self.input_names}")

    def run(
        self, windows: np.ndarray, baseline: np.ndarray, batch_size: int = 256
    ) -> tuple[np.ndarray, np.ndarray]:
        """windows [B, win, S]，baseline [baseline_len, S] → (probs [B, C], compensated [B, win, S])"""
        m = self.meta
        if windows.ndim != 3 or windows.shape[1:] != (m.win, m.n_sensors):
            raise AppError(
                "INVALID_TENSOR",
                f"windows 形状应为 [B, {m.win}, {m.n_sensors}]，实际为 {list(windows.shape)}。",
            )
        if baseline.shape != (m.baseline_len, m.n_sensors):
            raise AppError(
                "INVALID_TENSOR",
                f"baseline 形状应为 [{m.baseline_len}, {m.n_sensors}]，实际为 {list(baseline.shape)}。",
            )
        if windows.shape[0] == 0:
            raise AppError("INVALID_TENSOR", "windows 至少需要 1 个窗口。")
        windows = np.ascontiguousarray(windows, dtype=np.float32)
        baseline = np.ascontiguousarray(baseline, dtype=np.float32)
        probs_parts, comp_parts = [], []
        for i in range(0, windows.shape[0], batch_size):
            out = self.session.run(
                ["probs", "compensated_raw"],
                {"window_raw": windows[i : i + batch_size], "baseline_raw": baseline},
            )
            probs_parts.append(out[0])
            comp_parts.append(out[1])
        return np.concatenate(probs_parts), np.concatenate(comp_parts)
