"""FastAPI 入口。运行：uvicorn app.main:app --reload --port 8000"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Annotated

import numpy as np
import onnxruntime as ort
from fastapi import FastAPI, File, Form, Query, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from . import __version__
from .analysis import analyze, inspect
from .config import settings
from .errors import AppError
from .inference import ModelService
from .parsing import parse_table
from .schemas import (
    AnalysisResult,
    ErrorResponse,
    HealthResponse,
    InferRequest,
    InferResponse,
    InspectResult,
    ModelInfo,
)

logger = logging.getLogger("enose")

STRIDE_MIN, STRIDE_MAX = 1, 120


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    app.state.model = ModelService(settings.model_path, settings.meta_path, settings.metrics_path)
    logger.info("模型已加载：%s", settings.model_path)
    yield


app = FastAPI(
    title="电子鼻牛肉新鲜度推理服务",
    version=__version__,
    description="DCL 漂移补偿 + 改进 TCN，三分类：新鲜 / 次新鲜 / 腐败。",
    lifespan=lifespan,
    responses={422: {"model": ErrorResponse}},
)
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ---------- 错误处理：统一 {error: {code, message, detail}}，不回显堆栈 ----------


@app.exception_handler(AppError)
async def app_error_handler(_: Request, exc: AppError) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code, content=exc.to_dict())


@app.exception_handler(RequestValidationError)
async def validation_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    first = exc.errors()[0] if exc.errors() else {}
    field = ".".join(str(p) for p in first.get("loc", []) if p not in ("body", "query", "form"))
    err = AppError(
        "INVALID_REQUEST",
        f"请求参数不正确：{field or '未知字段'}。",
        detail={"errors": [{"loc": e.get("loc"), "type": e.get("type")} for e in exc.errors()]},
    )
    return JSONResponse(status_code=422, content=err.to_dict())


@app.exception_handler(Exception)
async def unhandled_handler(_: Request, exc: Exception) -> JSONResponse:
    logger.exception("未处理的异常", exc_info=exc)
    err = AppError("INTERNAL_ERROR", "服务器内部错误，请稍后重试。", status_code=500)
    return JSONResponse(status_code=500, content=err.to_dict())


def _model(request: Request) -> ModelService:
    return request.app.state.model


def _check_stride(stride: int) -> None:
    if not STRIDE_MIN <= stride <= STRIDE_MAX:
        raise AppError(
            "INVALID_REQUEST", f"步长需在 {STRIDE_MIN}–{STRIDE_MAX} 分钟之间，当前为 {stride}。"
        )


# ---------- 路由 ----------


@app.get("/api/health", response_model=HealthResponse, tags=["系统"])
def health(request: Request) -> HealthResponse:
    loaded = getattr(request.app.state, "model", None) is not None
    return HealthResponse(
        status="ok" if loaded else "degraded",
        model_loaded=loaded,
        version=__version__,
        onnxruntime=ort.__version__,
    )


@app.get("/api/model", response_model=ModelInfo, tags=["模型"])
def model_info(request: Request) -> ModelInfo:
    svc = _model(request)
    m = svc.meta
    return ModelInfo(
        task=m.task,
        sensors=m.sensors,
        class_names=m.class_names,
        win=m.win,
        baseline_len=m.baseline_len,
        default_stride=settings.default_stride,
        temperature=m.temperature,
        n_parameters=m.n_parameters,
        metrics=svc.metrics,
    )


async def _read_upload(file: UploadFile) -> bytes:
    content = await file.read(settings.max_upload_bytes + 1)
    if len(content) > settings.max_upload_bytes:
        raise AppError(
            "FILE_TOO_LARGE",
            f"文件超过 {settings.max_upload_bytes // (1024 * 1024)} MB 上限。",
            status_code=413,
        )
    return content


@app.post("/api/inspect", response_model=InspectResult, tags=["数据"])
async def inspect_file(
    request: Request,
    file: Annotated[UploadFile, File(description=".csv / .xlsx / .xls，≤ 10 MB")],
    stride: Annotated[int, Form()] = settings.default_stride,
    sheet: Annotated[str | None, Form()] = None,
) -> InspectResult:
    """只解析与校验数据，不运行模型：用于「数据核验」步骤。"""
    _check_stride(stride)
    content = await _read_upload(file)
    svc = _model(request)
    name = file.filename or "upload.csv"
    table = parse_table(
        content,
        name,
        svc.meta.sensors,
        min_rows=svc.meta.min_rows,
        max_rows=settings.max_rows,
        sheet=sheet or None,
    )
    return inspect(table, svc, file_name=name, stride=stride)


@app.post("/api/inspect/sample", response_model=InspectResult, tags=["数据"])
def inspect_sample(
    request: Request, stride: Annotated[int, Query()] = settings.default_stride
) -> InspectResult:
    _check_stride(stride)
    svc = _model(request)
    path = settings.sample_path
    table = parse_table(
        path.read_bytes(),
        path.name,
        svc.meta.sensors,
        min_rows=svc.meta.min_rows,
        max_rows=settings.max_rows,
    )
    return inspect(table, svc, file_name=path.name, stride=stride)


@app.post("/api/analyze", response_model=AnalysisResult, tags=["推理"])
async def analyze_file(
    request: Request,
    file: Annotated[UploadFile, File(description=".csv / .xlsx / .xls，≤ 10 MB")],
    stride: Annotated[int, Form()] = settings.default_stride,
    sheet: Annotated[str | None, Form()] = None,
    include_compensated: Annotated[bool, Form()] = True,
) -> AnalysisResult:
    _check_stride(stride)
    content = await _read_upload(file)
    svc = _model(request)
    name = file.filename or "upload.csv"
    table = parse_table(
        content,
        name,
        svc.meta.sensors,
        min_rows=svc.meta.min_rows,
        max_rows=settings.max_rows,
        sheet=sheet or None,
    )
    return analyze(
        table,
        svc,
        file_name=name,
        stride=stride,
        include_compensated=include_compensated,
        batch_size=settings.batch_size,
    )


@app.post("/api/analyze/sample", response_model=AnalysisResult, tags=["推理"])
def analyze_sample(
    request: Request,
    stride: Annotated[int, Query()] = settings.default_stride,
    include_compensated: Annotated[bool, Query()] = True,
) -> AnalysisResult:
    _check_stride(stride)
    svc = _model(request)
    path = settings.sample_path
    table = parse_table(
        path.read_bytes(),
        path.name,
        svc.meta.sensors,
        min_rows=svc.meta.min_rows,
        max_rows=settings.max_rows,
    )
    return analyze(
        table,
        svc,
        file_name=path.name,
        stride=stride,
        include_compensated=include_compensated,
        batch_size=settings.batch_size,
    )


@app.post("/api/infer", response_model=InferResponse, tags=["推理"])
def infer(request: Request, body: InferRequest) -> InferResponse:
    svc = _model(request)
    try:
        windows = np.asarray(body.windows, dtype=np.float32)
        baseline = np.asarray(body.baseline, dtype=np.float32)
    except ValueError as exc:  # 参差不齐的嵌套数组
        raise AppError("INVALID_TENSOR", "windows / baseline 必须是形状规整的数值数组。") from exc
    probs, comp = svc.run(windows, baseline, batch_size=settings.batch_size)
    return InferResponse(
        probs=np.round(probs.astype(np.float64), 6).tolist(),
        compensated=np.round(comp.astype(np.float64), 4).tolist(),
    )
