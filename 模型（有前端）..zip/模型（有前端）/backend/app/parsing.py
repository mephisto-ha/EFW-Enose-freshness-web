"""读取上传的表格并校验：列名容错、行数、数值、真实标签映射。"""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass
from pathlib import PurePath

import numpy as np
import pandas as pd

from .errors import AppError

SUPPORTED_EXT = {".csv", ".xlsx", ".xls"}
MINUTE_COLUMNS = ("minute", "minutes", "分钟", "时间(分钟)")
LABEL_COLUMNS = ("true_label", "label", "class", "freshness", "真实标签", "标签")
CUT_COLUMNS = ("cut", "部位")

# 中文标签 + 原数据集英文标签（excellent+good→新鲜，acceptable→次新鲜，spoiled→腐败）
LABEL_MAP: dict[str, int] = {
    "新鲜": 0,
    "fresh": 0,
    "excellent": 0,
    "good": 0,
    "次新鲜": 1,
    "acceptable": 1,
    "semi-fresh": 1,
    "sub-fresh": 1,
    "腐败": 2,
    "spoiled": 2,
    "spoilage": 2,
    "rotten": 2,
}

# 原始数据集（e-nose_dataset_12_beef_cuts.xlsx）的 Label 列是公式算出的数字：
# TVC<3→1(excellent)，<4→2(good)，<5→3(acceptable)，≥5→4(spoiled)。
# 按 excellent+good→新鲜、acceptable→次新鲜、spoiled→腐败 映射。
NUMERIC_LABEL_MAP: dict[float, int] = {1.0: 0, 2.0: 0, 3.0: 1, 4.0: 2}


@dataclass
class ParsedTable:
    signals: np.ndarray  # [rows, n_sensors] float32
    minutes: np.ndarray  # [rows] float64
    labels: list[int | None] | None
    cuts: list[str | None] | None
    sheet: str | None
    sheets: list[str]
    warnings: list[str]
    columns: list[str] | None = None
    minute_column: str | None = None
    label_column: str | None = None
    cut_column: str | None = None


def _ext(file_name: str) -> str:
    return PurePath(file_name).suffix.lower()


def _decode_text(content: bytes) -> str:
    for enc in ("utf-8-sig", "gb18030"):
        try:
            return content.decode(enc)
        except UnicodeDecodeError:
            continue
    raise AppError("UNREADABLE_FILE", "无法识别文件编码，请另存为 UTF-8 编码的 CSV 后重试。")


def _read_csv(content: bytes) -> pd.DataFrame:
    text = _decode_text(content)
    if not text.strip():
        raise AppError("EMPTY_FILE", "文件是空的。")
    try:
        sample = text[:4096]
        delimiter = csv.Sniffer().sniff(sample, delimiters=",;\t").delimiter
    except csv.Error:
        delimiter = ","
    try:
        return pd.read_csv(io.StringIO(text), sep=delimiter)
    except Exception as exc:  # pandas 抛出的异常类型很多，这里统一转成中文提示
        raise AppError("UNREADABLE_FILE", "CSV 解析失败，请检查是否为逗号分隔的表格。") from exc


def _read_excel(content: bytes, sheet: str | None) -> tuple[pd.DataFrame, str, list[str]]:
    try:
        book = pd.ExcelFile(io.BytesIO(content))
    except Exception as exc:
        raise AppError("UNREADABLE_FILE", "Excel 文件无法打开，可能已损坏或被加密。") from exc
    sheets = [str(s) for s in book.sheet_names]
    if not sheets:
        raise AppError("EMPTY_FILE", "Excel 文件里没有工作表。")
    chosen = sheet if sheet is not None else sheets[0]
    if chosen not in sheets:
        raise AppError(
            "SHEET_NOT_FOUND",
            f"找不到工作表「{chosen}」。可选：{'、'.join(sheets)}。",
            detail={"sheets": sheets},
        )
    return book.parse(chosen), chosen, sheets


def _find_column(columns: dict[str, str], candidates: tuple[str, ...]) -> str | None:
    for c in candidates:
        if c.lower() in columns:
            return columns[c.lower()]
    return None


def _map_label(value: object) -> int | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    if isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, bool):
        f = float(value)
        if np.isnan(f):
            return None
        return NUMERIC_LABEL_MAP.get(f)
    text = str(value).strip().lower()
    mapped = LABEL_MAP.get(text)
    if mapped is not None:
        return mapped
    try:
        return NUMERIC_LABEL_MAP.get(float(text))
    except ValueError:
        return None


def parse_table(
    content: bytes,
    file_name: str,
    sensors: list[str],
    *,
    min_rows: int,
    max_rows: int,
    sheet: str | None = None,
) -> ParsedTable:
    ext = _ext(file_name)
    if ext not in SUPPORTED_EXT:
        raise AppError(
            "UNSUPPORTED_FILE",
            f"不支持「{ext or '无扩展名'}」文件，请上传 .csv、.xlsx 或 .xls。",
            status_code=415,
        )
    if not content:
        raise AppError("EMPTY_FILE", "文件是空的。")

    if ext == ".csv":
        df, used_sheet, sheets = _read_csv(content), None, []
    else:
        df, used_sheet, sheets = _read_excel(content, sheet)

    df = df.dropna(how="all")
    if df.empty:
        raise AppError("EMPTY_FILE", "表格里没有数据行。")

    # 列名容错：去空格、忽略大小写
    lookup = {str(c).strip().lower(): c for c in df.columns}
    missing = [s for s in sensors if s.lower() not in lookup]
    if missing:
        raise AppError(
            "MISSING_COLUMNS",
            f"缺少传感器列：{'、'.join(missing)}。表头需要包含全部 {len(sensors)} 个传感器列"
            f"（{'、'.join(sensors)}）。",
            detail={"missing": missing, "found": [str(c) for c in df.columns]},
        )

    n = len(df)
    if n < min_rows:
        raise AppError(
            "TOO_FEW_ROWS",
            f"数据只有 {n} 行，至少需要 {min_rows} 行（前 20 行作新鲜基线，再加一个 60 分钟窗口）。",
            detail={"rows": n, "min_rows": min_rows},
        )
    if n > max_rows:
        raise AppError(
            "TOO_MANY_ROWS",
            f"数据有 {n} 行，超过上限 {max_rows} 行。请拆分文件后分别分析。",
            detail={"rows": n, "max_rows": max_rows},
        )

    sensor_cols = [lookup[s.lower()] for s in sensors]
    numeric = df[sensor_cols].apply(pd.to_numeric, errors="coerce")
    bad = numeric.isna().to_numpy()
    if bad.any():
        r, c = map(int, np.argwhere(bad)[0])
        raw_value = df[sensor_cols].iloc[r, c]
        shown = "空" if pd.isna(raw_value) else f"「{raw_value}」"
        row_no = r + 1
        raise AppError(
            "NON_NUMERIC",
            f"第 {row_no} 行（表格第 {row_no + 1} 行）的 {sensors[c]} 列不是有效数字：{shown}。"
            f"共有 {int(bad.sum())} 处这类问题，请补全或删除这些行。",
            detail={"row": row_no, "column": sensors[c], "count": int(bad.sum())},
        )
    signals = numeric.to_numpy(dtype=np.float32)

    warnings: list[str] = []
    minute_col = _find_column(lookup, MINUTE_COLUMNS)
    minutes = np.arange(1, n + 1, dtype=np.float64)
    if minute_col is not None:
        m = pd.to_numeric(df[minute_col], errors="coerce").to_numpy(dtype=np.float64)
        if np.isnan(m).any() or not np.all(np.diff(m) > 0):
            warnings.append("「分钟」列缺失值或不是递增的，已改用行号作为时间轴。")
        else:
            minutes = m

    labels: list[int | None] | None = None
    label_col = _find_column(lookup, LABEL_COLUMNS)
    if label_col is not None:
        mapped = [_map_label(v) for v in df[label_col].tolist()]
        if any(v is not None for v in mapped):
            labels = mapped

    cuts: list[str | None] | None = None
    cut_col = _find_column(lookup, CUT_COLUMNS)
    if cut_col is not None and labels is not None:
        cuts = [None if pd.isna(v) else str(v) for v in df[cut_col].tolist()]

    return ParsedTable(
        signals=signals,
        minutes=minutes,
        labels=labels,
        cuts=cuts,
        sheet=used_sheet,
        sheets=sheets,
        warnings=warnings,
        columns=[str(c) for c in df.columns],
        minute_column=None if minute_col is None else str(minute_col),
        label_column=None if labels is None or label_col is None else str(label_col),
        cut_column=None if cuts is None or cut_col is None else str(cut_col),
    )
