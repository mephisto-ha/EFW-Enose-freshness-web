"""接口数据结构（OpenAPI 由此生成，前端类型与之对齐）。"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

ClassIndex = Literal[0, 1, 2]


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    model_loaded: bool
    version: str
    onnxruntime: str


class ModelInfo(BaseModel):
    task: str
    sensors: list[str]
    class_names: list[str]
    win: int
    baseline_len: int
    default_stride: int
    temperature: float
    n_parameters: int
    metrics: dict[str, Any]


class SourceInfo(BaseModel):
    file_name: str
    sheet: str | None = None
    sheets: list[str] = Field(default_factory=list)
    rows: int
    engine: Literal["server", "browser"] = "server"


class ModelParams(BaseModel):
    sensors: list[str]
    class_names: list[str]
    win: int
    baseline_len: int
    stride: int


class Series(BaseModel):
    minute: list[float]
    values: list[list[float]] = Field(description="values[传感器下标][行下标]")


class TruthSegment(BaseModel):
    start_row: int
    end_row: int
    label: ClassIndex | None
    cut: str | None = None


class Truth(BaseModel):
    labels: list[ClassIndex | None]
    segments: list[TruthSegment]


class WindowResult(BaseModel):
    index: int
    start_row: int = Field(description="窗口起始行，1 起计")
    end_row: int = Field(description="窗口结束行，1 起计，与参考脚本 row_end 一致")
    minute_start: float
    minute_end: float
    pred: ClassIndex
    confidence: float
    probs: list[float]
    truth: ClassIndex | None = None


class Agreement(BaseModel):
    matched: int
    total: int


class Latest(BaseModel):
    pred: ClassIndex
    confidence: float


class Summary(BaseModel):
    counts: list[int]
    first_minute: list[float | None]
    agreement: Agreement | None = None
    latest: Latest


class AnalysisResult(BaseModel):
    source: SourceInfo
    model: ModelParams
    series: Series
    truth: Truth | None = None
    windows: list[WindowResult]
    compensated: list[list[list[float]]] | None = Field(
        default=None, description="[窗口][传感器][时间步]，漂移补偿后的读数（原始单位）"
    )
    summary: Summary
    warnings: list[str] = Field(default_factory=list)
    elapsed_ms: float


class InspectResult(BaseModel):
    """数据核验：只解析和校验，不跑模型。"""

    file_name: str
    sheet: str | None = None
    sheets: list[str] = Field(default_factory=list)
    rows: int
    columns: list[str]
    sensors: list[str]
    minute_column: str | None = None
    label_column: str | None = None
    cut_column: str | None = None
    duration_minutes: float
    baseline_len: int
    win: int
    stride: int
    n_windows: int
    first_judgement_minute: float
    truth_counts: list[int] | None = Field(default=None, description="每类真实标签的行数")
    preview: list[list[float]] = Field(description="前 5 行传感器读数，[行][传感器]")
    warnings: list[str] = Field(default_factory=list)


class InferRequest(BaseModel):
    windows: list[list[list[float]]] = Field(description="形状 [B, 60, 11]")
    baseline: list[list[float]] = Field(description="形状 [20, 11]")


class InferResponse(BaseModel):
    probs: list[list[float]]
    compensated: list[list[list[float]]]


class ErrorBody(BaseModel):
    code: str
    message: str
    detail: dict[str, Any] = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    error: ErrorBody
