from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import app

ASSETS = Path(__file__).resolve().parent.parent / "assets"


@pytest.fixture(scope="session")
def client() -> Iterator[TestClient]:
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="session")
def sample_bytes() -> bytes:
    return (ASSETS / "samples" / "sample_beef_input.csv").read_bytes()


@pytest.fixture(scope="session")
def reference_csv() -> Path:
    return ASSETS / "samples" / "sample_predictions.csv"
