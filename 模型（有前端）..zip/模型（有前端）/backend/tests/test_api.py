from __future__ import annotations

import io

import pandas as pd

SENSORS = ["MQ135", "MQ136", "MQ137", "MQ138", "MQ2", "MQ3", "MQ4", "MQ5", "MQ6", "MQ8", "MQ9"]


def _csv(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def _post(client, content: bytes, name: str = "x.csv", **data):
    return client.post("/api/analyze", files={"file": (name, content, "text/csv")}, data=data)


def _sample_df(sample_bytes: bytes) -> pd.DataFrame:
    return pd.read_csv(io.BytesIO(sample_bytes), encoding="utf-8-sig")


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["model_loaded"] is True


def test_model_info(client):
    body = client.get("/api/model").json()
    assert body["sensors"] == SENSORS
    assert body["class_names"] == ["新鲜", "次新鲜", "腐败"]
    assert body["metrics"]["macro_f1"] == 0.657
    assert len(body["metrics"]["per_cut_f1"]) == 12


def test_unsupported_extension(client):
    r = _post(client, b"abc", name="data.txt")
    assert r.status_code == 415
    assert r.json()["error"]["code"] == "UNSUPPORTED_FILE"


def test_missing_columns(client, sample_bytes):
    df = _sample_df(sample_bytes).drop(columns=["MQ8", "MQ9"])
    r = _post(client, _csv(df))
    assert r.status_code == 422
    err = r.json()["error"]
    assert err["code"] == "MISSING_COLUMNS"
    assert err["detail"]["missing"] == ["MQ8", "MQ9"]


def test_too_few_rows(client, sample_bytes):
    df = _sample_df(sample_bytes).head(50)
    r = _post(client, _csv(df))
    assert r.json()["error"]["code"] == "TOO_FEW_ROWS"


def test_non_numeric_reports_row_and_column(client, sample_bytes):
    df = _sample_df(sample_bytes)
    df["MQ4"] = df["MQ4"].astype(object)
    df.loc[99, "MQ4"] = "err"
    r = _post(client, _csv(df))
    err = r.json()["error"]
    assert err["code"] == "NON_NUMERIC"
    assert err["detail"] == {"row": 100, "column": "MQ4", "count": 1}


def test_column_names_are_case_and_space_insensitive(client, sample_bytes):
    df = _sample_df(sample_bytes)
    df.columns = [f" {c.lower()} " if c.startswith("MQ") else c for c in df.columns]
    r = _post(client, _csv(df))
    assert r.status_code == 200, r.text


def test_no_minute_or_label_columns(client, sample_bytes):
    df = _sample_df(sample_bytes)[SENSORS]
    body = _post(client, _csv(df)).json()
    assert body["truth"] is None
    assert body["summary"]["agreement"] is None
    assert body["series"]["minute"][0] == 1.0


def test_english_labels_mapped(client, sample_bytes):
    df = _sample_df(sample_bytes)
    mapping = {"新鲜": "good", "次新鲜": "acceptable", "腐败": "spoiled"}
    df["true_label"] = df["true_label"].map(lambda v: mapping.get(v, v))
    body = _post(client, _csv(df)).json()
    assert body["truth"]["labels"][-1] == 2


def test_gbk_encoded_csv(client, sample_bytes):
    df = _sample_df(sample_bytes)
    r = _post(client, df.to_csv(index=False).encode("gb18030"))
    assert r.status_code == 200
    assert r.json()["truth"]["labels"][30] == 0


def test_xlsx_with_sheets(client, sample_bytes):
    df = _sample_df(sample_bytes)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="4.Tenderloin", index=False)
        df.head(200).to_excel(w, sheet_name="6.Striploin", index=False)
    content = buf.getvalue()
    r = client.post(
        "/api/analyze",
        files={"file": ("beef.xlsx", content, "application/octet-stream")},
        data={"sheet": "6.Striploin"},
    )
    body = r.json()
    assert body["source"]["sheets"] == ["4.Tenderloin", "6.Striploin"]
    assert body["source"]["sheet"] == "6.Striploin"
    assert body["source"]["rows"] == 200
    r2 = client.post(
        "/api/analyze",
        files={"file": ("beef.xlsx", content, "application/octet-stream")},
        data={"sheet": "不存在"},
    )
    assert r2.json()["error"]["code"] == "SHEET_NOT_FOUND"


def test_stride_changes_window_count(client):
    body = client.post("/api/analyze/sample?stride=30").json()
    assert body["model"]["stride"] == 30
    assert len(body["windows"]) == 11


def test_invalid_stride(client):
    r = client.post("/api/analyze/sample?stride=0")
    assert r.json()["error"]["code"] == "INVALID_REQUEST"


def test_file_too_large(client):
    r = _post(client, b"0" * (10 * 1024 * 1024 + 10))
    assert r.status_code == 413


def test_infer_endpoint(client, sample_bytes):
    df = _sample_df(sample_bytes)[SENSORS]
    sig = df.to_numpy().tolist()
    r = client.post("/api/infer", json={"windows": [sig[20:80]], "baseline": sig[:20]})
    assert r.status_code == 200
    body = r.json()
    assert abs(body["probs"][0][0] - 0.9931) < 1e-3
    r_bad = client.post("/api/infer", json={"windows": [sig[20:70]], "baseline": sig[:20]})
    assert r_bad.json()["error"]["code"] == "INVALID_TENSOR"
