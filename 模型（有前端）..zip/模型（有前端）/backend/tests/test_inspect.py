from __future__ import annotations

import io

import pandas as pd


def test_inspect_sample(client):
    body = client.post("/api/inspect/sample").json()
    assert body["rows"] == 380
    assert body["n_windows"] == 31
    assert body["first_judgement_minute"] == 80.0
    assert body["minute_column"] == "minute"
    assert body["label_column"] == "true_label"
    assert body["cut_column"] == "cut"
    assert body["truth_counts"] == [120, 120, 120]
    assert len(body["preview"]) == 5 and len(body["preview"][0]) == 11


def test_inspect_tab_separated_paste(client, sample_bytes):
    df = pd.read_csv(io.BytesIO(sample_bytes), encoding="utf-8-sig")
    tsv = df.to_csv(index=False, sep="\t").encode("utf-8")
    r = client.post("/api/inspect", files={"file": ("粘贴数据.csv", tsv, "text/csv")})
    assert r.status_code == 200, r.text
    assert r.json()["rows"] == 380


def test_inspect_reports_errors_like_analyze(client, sample_bytes):
    df = pd.read_csv(io.BytesIO(sample_bytes), encoding="utf-8-sig").drop(columns=["MQ2"])
    r = client.post(
        "/api/inspect", files={"file": ("x.csv", df.to_csv(index=False).encode(), "text/csv")}
    )
    assert r.json()["error"]["code"] == "MISSING_COLUMNS"
