"""与交付包参考结果（inference_onnx.py 实测输出）逐项对比。"""

from __future__ import annotations

import pandas as pd

CLASSES = ["新鲜", "次新鲜", "腐败"]


def test_sample_matches_reference(client, sample_bytes, reference_csv):
    ref = pd.read_csv(reference_csv, encoding="utf-8-sig")
    r = client.post(
        "/api/analyze",
        files={"file": ("sample_beef_input.csv", sample_bytes, "text/csv")},
        data={"stride": "10"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    wins = body["windows"]
    assert len(wins) == len(ref) == 31
    for w, (_, row) in zip(wins, ref.iterrows(), strict=True):
        assert w["end_row"] == row["row_end"]
        assert CLASSES[w["pred"]] == row["pred"]
        assert abs(w["confidence"] - row["confidence"]) < 1e-3
        for i, name in enumerate(CLASSES):
            assert abs(w["probs"][i] - row[f"p_{name}"]) < 1e-3


def test_sample_endpoint_equals_upload(client, sample_bytes):
    a = client.post("/api/analyze/sample").json()
    b = client.post(
        "/api/analyze", files={"file": ("sample_beef_input.csv", sample_bytes, "text/csv")}
    ).json()
    assert [w["probs"] for w in a["windows"]] == [w["probs"] for w in b["windows"]]


def test_summary_and_truth(client):
    body = client.post("/api/analyze/sample").json()
    s = body["summary"]
    assert sum(s["counts"]) == 31
    assert s["counts"] == [13, 16, 2]
    assert s["first_minute"] == [80.0, 210.0, 370.0]
    assert body["truth"] is not None
    # 7 段：基线 + 三类各 2 段
    assert len(body["truth"]["segments"]) == 7
    assert s["agreement"]["total"] == 31
    assert body["compensated"] is not None
    assert len(body["compensated"]) == 31
    assert len(body["compensated"][0]) == 11
    assert len(body["compensated"][0][0]) == 60
