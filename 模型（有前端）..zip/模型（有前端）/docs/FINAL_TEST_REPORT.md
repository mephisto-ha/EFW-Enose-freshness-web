# 最终测试报告

2026-10-09 13:32

## 牛肉新鲜度模型

**泛化能力**

- macro-F1：**0.657**；balanced accuracy：0.662
- 各类 F1：新鲜 0.813，次新鲜 0.313，腐败 0.844
- 混淆矩阵（行=真实 新鲜/次新鲜/腐败）：[[991, 280, 85], [85, 278, 261], [6, 595, 2567]]

| 部位               | 留一 macro-F1 |
| ---------------- | ----------- |
| 1.Inside-Outside | 0.780       |
| 2.Round          | 0.556       |
| 3.Top_Sirloin    | 0.636       |
| 4.Tenderloin     | 0.819       |
| 5.Flap_meat      | 0.506       |
| 6.Striploin      | 0.879       |
| 7.Rib_eye        | 0.559       |
| 8.Skirt_meat     | 0.477       |
| 9.Brisket        | 0.505       |
| 10.Clod_Chuck    | 0.723       |
| 11.Shin          | 0.572       |
| 12.Fat           | 0.496       |

**模型文件功能测试**

- 测试窗口：2580 个（步长 10）；macro-F1 0.922
- ONNX：可用；与 PyTorch 概率最大差 1.07e-06，预测一致率 1.0000
- 速度（CPU）：单窗口 6.94 ms，256 窗口 22.1 ms（PyTorch）
- 参数量 120,029；文件大小 {'model.pt': 486, 'model.onnx': 500} KB

## UCI 漂移验证模型

| 批次 | 准确率   |
| -- | ----- |
| 1  | 1.000 |
| 2  | 0.808 |
| 3  | 0.696 |
| 4  | 0.671 |
| 5  | 0.533 |
| 6  | 0.602 |
| 7  | 0.426 |
| 8  | 0.293 |
| 9  | 0.451 |
| 10 | 0.552 |

- batch2~~10 平均：**0.559**（batch1 为有标签参考批次；batch2~~10 的特征（无标签）参与了适配，属于直推式评测。）
- 基线：逻辑回归 不补偿 0.507，+线性 OT 0.660；随机森林 不补偿 0.491
- ONNX：可用，预测一致率 1.0000

## 图表

- `figures/beef_loco_confusion.png`
- `figures/beef_per_cut_f1.png`
- `figures/beef_tuning.png`
- `figures/beef_training_curves.png`
- `figures/uci_training_curves.png`
- `figures/uci_per_batch_accuracy.png`
