# 模型说明（Model Card）

## 1. 概述

AI 嗅觉电子鼻食品新鲜度识别模型。结构：漂移补偿层 DCL → 传感器通道注意力 → 改进 TCN（膨胀因果卷积 + 块内 ECA） → 时间步注意力 → 全连接 → 温度缩放校准。预处理、漂移上下文计算与校准均已内置于模型文件。

## 2. 牛肉新鲜度模型（主交付）

- 任务：牛肉新鲜度三分类（新鲜 / 次新鲜 / 腐败）
- 类别：新鲜、次新鲜、腐败
- 文件：`model_beef/model.pt`、`model_beef/model.onnx`
- 参数量：120,029；温度 T = 1.861
- 输入：
  - `window_raw`：(B, 60, 11) float32：60 分钟原始读数，行=分钟，列按 sensors 顺序
  - `baseline_raw`：(20, 11) float32：开始监测的前 20 分钟原始读数（新鲜基线）
- 输出：
  - `probs`：(B, 3) 温度校准后的类别概率
  - `compensated_raw`：(B, 60, 11) 漂移补偿后的常规数据（原始单位）
- **评估（按部位留一，测试部位不参与训练）**：macro-F1 **0.657**，balanced accuracy 0.662；各类 F1 新鲜 0.813，次新鲜 0.313，腐败 0.844
- 速度：单窗口 6.94 ms（PyTorch，CPU），0.48 ms（ONNX）

## 3. UCI 漂移验证模型（辅助）

- 任务：UCI 气体传感器阵列漂移数据：6 种气体分类（补偿层抗漂移验证）
- 类别：乙醇、乙烯、氨、乙醛、丙酮、甲苯
- 文件：`model_uci/model.pt`、`model_uci/model.onnx`
- 参数量：47,155；温度 T = 1.285
- 输入：
  - `x_raw`：(B, 128) float32：原始 128 维特征
  - `ctx_raw`：(K, 128) float32：同一时期的无标签样本（可为 x_raw 本身，K≥30）
  - `t`：(1,) float32：归一化时间（批次号 / 10）
- 输出：
  - `probs`：(B, 6) 温度校准后的类别概率
  - `compensated_raw`：(B, 128) 漂移补偿后的常规数据（原始单位）
- 评估：batch2~10 平均准确率 0.559（直推式：漂移批次无标签参与适配）

## 4. 训练数据

- 牛肉：Wijaya, D. R. (2022). Dataset for electronic nose from various beef cuts. Harvard Dataverse, V2. <https://doi.org/10.7910/DVN/XNFVTS（CC0> 1.0）。12 个部位 × 2220 分钟 × 11 路 MQ 传感器；标签 excellent+good→新鲜、acceptable→次新鲜、spoiled→腐败；TVC 与时间未作为输入。
- UCI：Vergara, A. (2012). Gas Sensor Array Drift Dataset. UCI Machine Learning Repository. <https://doi.org/10.24432/C5RP6W。13910> 条、10 个批次（36 个月）、128 维特征、6 种气体。
- 训练数据导出见 `training_data/`。

## 5. 适用范围与局限

- 牛肉数据 12 个部位换级时刻几乎相同、只有一种储存条件，结论限于同一实验条件下对新部位的泛化。
- 漂移上下文假设开始监测的前 20 分钟为新鲜基线；数据中无洁净空气段。
- MQ 传感器读数的变化中可能混有预热漂移，本数据无法与变质信号区分。
- UCI 结果为直推式评测；补偿层效果表述为"在标准漂移基准上验证"。

## 6. 使用

```bash
pip install -r requirements_inference.txt
python inference_onnx.py --data 你的数据.xlsx
```
