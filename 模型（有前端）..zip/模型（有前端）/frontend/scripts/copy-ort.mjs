// 把 onnxruntime-web 的运行时（UMD 脚本 + wasm）复制到 public/ort/，
// 浏览器引擎从同源加载，不依赖外部 CDN，也绕开打包器对 .wasm/.mjs 的处理问题。
import { cpSync, existsSync, mkdirSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const src = join(root, "node_modules", "onnxruntime-web", "dist");
const dest = join(root, "public", "ort");

if (!existsSync(src)) {
  console.warn("[copy-ort] 未找到 onnxruntime-web，跳过");
  process.exit(0);
}
mkdirSync(dest, { recursive: true });
const wanted = (f) =>
  f === "ort.wasm.min.js" || (f.startsWith("ort-wasm-simd-threaded") && /\.(wasm|mjs)$/.test(f) && !f.includes("jsep") && !f.includes("jspi") && !f.includes("asyncify"));
const files = readdirSync(src).filter(wanted);
for (const f of files) cpSync(join(src, f), join(dest, f));
console.log(`[copy-ort] 已复制 ${files.length} 个文件到 public/ort/：${files.join(", ")}`);
