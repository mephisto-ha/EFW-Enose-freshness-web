"use client";

export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="mx-auto max-w-[1080px] px-5 py-20 sm:px-8">
      <h1 className="text-2xl font-semibold">页面出错了</h1>
      <p className="mt-3 text-ink-2">界面渲染时遇到问题。数据没有被上传或保存，重新加载即可。</p>
      <button type="button" onClick={reset} className="mt-6 rounded-sm bg-ink px-4 py-2 text-paper">
        重新加载
      </button>
    </div>
  );
}
