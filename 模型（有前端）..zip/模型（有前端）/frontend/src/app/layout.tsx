import "@fontsource-variable/instrument-sans/wdth.css";
import "@fontsource-variable/big-shoulders-display";
import "@fontsource/zcool-qingke-huangyou";
import "./globals.css";

import type { Metadata, Viewport } from "next";

import { SiteHeader } from "@/components/SiteHeader";

export const metadata: Metadata = {
  title: { default: "电子鼻牛肉新鲜度分析台", template: "%s｜电子鼻牛肉新鲜度分析台" },
  description: "上传电子鼻传感器读数，查看 DCL + TCN 模型在每个时间窗口对牛肉新鲜度的判定。",
  icons: { icon: "/icon.svg" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#ff4f9a",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <body className="flex min-h-dvh flex-col bg-paper text-ink antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-50 focus:bg-surface focus:px-3 focus:py-1"
        >
          跳到主要内容
        </a>
        <SiteHeader />
        <main id="main" className="flex-1">
          {children}
        </main>
        <footer className="mt-10">
          <div aria-hidden className="gingham h-6 border-y-2 border-ink" />
          <div className="bg-ink px-5 py-5 text-sm text-paper sm:px-8">
            研究演示，不作为食品安全判定依据。模型与数据说明见「模型说明」页。
          </div>
        </footer>
      </body>
    </html>
  );
}
