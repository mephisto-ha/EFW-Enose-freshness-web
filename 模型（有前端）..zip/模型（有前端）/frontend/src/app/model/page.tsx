import type { Metadata } from "next";
import Image from "next/image";

import { ConfusionMatrix } from "@/components/model/ConfusionMatrix";
import { PerCutF1 } from "@/components/model/PerCutF1";
import meta from "@/data/model-meta.json";
import metrics from "@/data/metrics.json";
import { CLASS_TEXT } from "@/lib/classes";

export const metadata: Metadata = { title: "模型说明" };

const PIPELINE = [
  { name: "原始读数", note: "60 分钟 × 11 路，外加开头 20 分钟基线" },
  { name: "漂移补偿层 DCL", note: "按基线估计增益与偏置，校正传感器漂移" },
  { name: "传感器通道注意力", note: "ECA，学习哪几路传感器更重要" },
  { name: "改进 TCN", note: "膨胀因果卷积 4 层，块内 ECA" },
  { name: "时间步注意力", note: "在 60 分钟里挑出关键时段" },
  { name: "全连接 + 温度缩放", note: `T = ${meta.temperature.toFixed(3)}，输出校准后的三类概率` },
];

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section aria-labelledby={id} className="panel p-6 sm:p-8">
      <h2 id={id} className="text-[1.9rem] leading-tight">
        {title}
      </h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

export default function ModelPage() {
  const names = meta.class_names;
  const perClass = names.map((n) => metrics.per_class_f1[n as keyof typeof metrics.per_class_f1]);

  return (
    <article className="mx-auto max-w-[1120px] space-y-10 px-5 pb-10 pt-10 sm:px-8 sm:pt-14">
      <header className="max-w-[64ch]">
        <h1 className="text-[3rem] leading-none sm:text-[4rem]">模型说明</h1>
        <ul className="mt-5 flex flex-wrap gap-3" aria-label="模型概况">
          <li className="sticker -rotate-2 bg-cobalt text-white">DCL 漂移补偿</li>
          <li className="sticker rotate-1 bg-semi text-ink">改进 TCN</li>
          <li className="sticker -rotate-1 bg-pink text-white">
            <span className="numeral text-base">120,029</span> 个参数
          </li>
          <li className="sticker rotate-2 bg-fresh text-white">温度缩放校准</li>
        </ul>
        <p className="mt-4 text-ink-2">
          电子鼻牛肉新鲜度三分类模型：先用漂移补偿层把传感器读数校正到稳定状态，再用改进的时间卷积网络读 60
          分钟的气味变化曲线。预处理、漂移估计和概率校准都封装在模型文件里，直接输入原始读数即可。
        </p>
      </header>

      <Section id="pipeline" title="一个窗口经过的步骤">
        <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PIPELINE.map((p, i) => (
            <li key={p.name} className="rounded-2xl border-2 border-ink bg-paper px-4 py-3.5">
              <p className="flex items-baseline gap-2.5">
                <span className="numeral grid size-7 shrink-0 place-items-center rounded-full border-2 border-ink bg-semi text-base">
                  {i + 1}
                </span>
                <span className="font-semibold">{p.name}</span>
              </p>
              <p className="mt-1.5 pl-9 text-sm text-ink-2">{p.note}</p>
            </li>
          ))}
        </ol>
        <p className="mt-3 text-sm text-ink-3">
          参数量 {meta.n_parameters.toLocaleString("zh-CN")}；ONNX 文件 504 KB；CPU 上单窗口推理{" "}
          {metrics.latency_ms_onnx_cpu} ms。
        </p>
      </Section>

      <Section id="metrics" title="成绩：换一个没见过的部位，还能判多准">
        <p className="max-w-[68ch] text-ink-2">
          {metrics.protocol}。腐败类样本占六成，所以只看准确率会虚高，这里报 macro-F1 和 balanced accuracy。
        </p>
        <dl className="mt-6 grid grid-cols-2 gap-x-8 gap-y-6 sm:grid-cols-5">
          <div>
            <dt className="text-sm text-ink-2">macro-F1</dt>
            <dd className="numeral text-[2.75rem] leading-none">{metrics.macro_f1.toFixed(3)}</dd>
          </div>
          <div>
            <dt className="text-sm text-ink-2">balanced accuracy</dt>
            <dd className="numeral text-[2.75rem] leading-none">{metrics.balanced_accuracy.toFixed(3)}</dd>
          </div>
          {names.map((n, c) => (
            <div key={n}>
              <dt className={`text-sm ${CLASS_TEXT[c]}`}>{n} F1</dt>
              <dd className="numeral text-[2.75rem] leading-none">{perClass[c].toFixed(3)}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-10 grid gap-10 lg:grid-cols-2">
          <div>
            <h3 className="font-display mb-3 text-xl">混淆矩阵</h3>
            <ConfusionMatrix matrix={metrics.confusion} names={names} />
            <p className="mt-3 max-w-[56ch] text-sm text-ink-2">
              最大的混淆在「腐败 → 次新鲜」（595
              个窗口）：模型察觉变质偏晚半拍。次新鲜本身是过渡状态，样本少、边界模糊，是三类里最难的。
            </p>
          </div>
          <div>
            <h3 className="font-display mb-3 text-xl">各部位留一 macro-F1</h3>
            <PerCutF1 data={metrics.per_cut_f1} overall={metrics.macro_f1} />
          </div>
        </div>
      </Section>

      <Section id="ablation" title="调参与对照">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="text-left text-ink-3">
              <tr className="border-b border-rule">
                <th className="py-2 pr-4 font-normal">方案</th>
                <th className="py-2 pr-4 font-normal">λ_adv</th>
                <th className="py-2 pr-4 font-normal">λ_id</th>
                <th className="py-2 pr-4 font-normal">窗口</th>
                <th className="py-2 pr-4 text-right font-normal">macro-F1</th>
                <th className="py-2 text-right font-normal">balanced acc</th>
              </tr>
            </thead>
            <tbody>
              {metrics.ablation.map((a, i) => (
                <tr key={a.name} className={`border-b border-grid ${i === 0 ? "font-semibold" : ""}`}>
                  <td className="py-2 pr-4">{a.name}</td>
                  <td className="numeral py-2 pr-4">{a.lambda_adv}</td>
                  <td className="numeral py-2 pr-4">{a.lambda_id}</td>
                  <td className="numeral py-2 pr-4">{a.win}</td>
                  <td className="numeral py-2 pr-4 text-right">{a.macro_f1.toFixed(3)}</td>
                  <td className="numeral py-2 text-right">{a.balanced_accuracy.toFixed(3)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 max-w-[72ch] text-sm text-ink-2">
          参数由同一留一评估选出（5 组候选），分数略偏乐观。温度缩放把校准误差 ECE 从 {metrics.ece_before}{" "}
          降到 {metrics.ece_after}。
        </p>
        <figure className="mt-8">
          <Image
            src="/figures/beef_training_curves.png"
            alt="牛肉模型训练曲线"
            width={2560}
            height={600}
            className="h-auto w-full max-w-[880px] rounded-sm border border-rule bg-white"
          />
          <figcaption className="mt-2 text-sm text-ink-3">
            训练曲线（原始图）。另有{" "}
            <a className="underline underline-offset-4" href="/figures/beef_loco_confusion.png">
              混淆矩阵原图
            </a>{" "}
            和{" "}
            <a className="underline underline-offset-4" href="/figures/beef_per_cut_f1.png">
              各部位 F1 原图
            </a>
            。
          </figcaption>
        </figure>
      </Section>

      <Section id="io" title="输入与输出">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <tbody>
              {[
                [
                  "window_raw",
                  "输入",
                  "[B, 60, 11] float32",
                  "60 分钟原始读数，列顺序：" + meta.sensors.join("、"),
                ],
                [
                  "baseline_raw",
                  "输入",
                  "[20, 11] float32",
                  "开始监测的前 20 分钟读数（新鲜基线），整个文件共用",
                ],
                ["probs", "输出", "[B, 3]", "温度校准后的概率，顺序：" + names.join("、")],
                [
                  "compensated_raw",
                  "输出",
                  "[B, 60, 11]",
                  "漂移补偿后的读数（原始单位），分析台底部的小图即来自它",
                ],
              ].map(([k, dir, shape, desc]) => (
                <tr key={k} className="border-b border-grid align-top">
                  <td className="py-2.5 pr-4 font-semibold">{k}</td>
                  <td className="py-2.5 pr-4 text-ink-3">{dir}</td>
                  <td className="numeral py-2.5 pr-4 whitespace-nowrap">{shape}</td>
                  <td className="py-2.5 text-ink-2">{desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-sm text-ink-2">
          滑窗规则：前 20 行作基线，第一个判定出现在第 80 行，之后每隔「步长」行出一个判定。接口文档见后端
          <code className="mx-1 rounded-sm bg-surface px-1">/docs</code>。
        </p>
      </Section>

      <Section id="limits" title="局限">
        <ul className="max-w-[72ch] list-disc space-y-2 pl-5 text-ink-2 marker:text-ink-3">
          <li>
            对照组里，直接用原始读数训练的随机森林 macro-F1 为 {metrics.baseline_random_forest_macro_f1}
            ，高于本模型的 {metrics.macro_f1}。本模型的价值在漂移补偿结构，单看这组数据的分类分数并不占优。
          </li>
          <li>次新鲜类 F1 只有 {metrics.per_class_f1["次新鲜"]}，过渡阶段的判定不可靠，常被判早或判晚。</li>
          <li>12 个部位的换级时刻几乎相同、只有一种储存条件，结论只适用于同一实验条件下的新部位。</li>
          <li>漂移估计假设开始监测的前 20 分钟是新鲜状态；数据中没有洁净空气段。</li>
          <li>MQ 传感器读数的变化中可能混有预热漂移，现有数据无法把它和变质信号完全分开。</li>
          <li>这是研究演示，不能代替菌落总数等食品安全检测。</li>
        </ul>
      </Section>

      <Section id="data" title="数据与许可">
        <p className="max-w-[72ch] text-ink-2">
          {metrics.dataset.citation}{" "}
          <a
            className="break-all underline underline-offset-4"
            href={metrics.dataset.doi}
            rel="noreferrer"
            target="_blank"
          >
            {metrics.dataset.doi}
          </a>
          （{metrics.dataset.license}）。{metrics.dataset.description}。
        </p>
        <p className="mt-3 max-w-[72ch] text-sm text-ink-3">
          DCL 对抗训练组件参照 Transfer-Learning-Library（MIT）重写；TCN 结构来自 locuslab/TCN（MIT）；ECA
          来自 ECA-Net（MIT）；温度缩放参照 gpleiss/temperature_scaling。
        </p>
      </Section>
    </article>
  );
}
