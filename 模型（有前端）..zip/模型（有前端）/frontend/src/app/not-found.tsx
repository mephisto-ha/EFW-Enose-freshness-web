import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-[1080px] px-5 py-20 sm:px-8">
      <h1 className="text-2xl font-semibold">没有这个页面</h1>
      <p className="mt-3 text-ink-2">地址可能输错了。</p>
      <Link href="/" className="mt-6 inline-block rounded-sm bg-ink px-4 py-2 text-paper">
        回到分析台
      </Link>
    </div>
  );
}
