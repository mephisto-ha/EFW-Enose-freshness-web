"use client";

import { useEffect } from "react";

import { useWorkspace } from "@/store/workspace";

export function EngineStatus() {
  const serverStatus = useWorkspace((s) => s.serverStatus);
  const engine = useWorkspace((s) => s.engine);
  const checkServer = useWorkspace((s) => s.checkServer);

  useEffect(() => {
    void checkServer();
  }, [checkServer]);

  const ok = engine === "browser" || serverStatus === "online";
  const text =
    engine === "browser"
      ? "浏览器推理"
      : serverStatus === "online"
        ? "推理服务在线"
        : serverStatus === "checking"
          ? "正在连接推理服务"
          : "推理服务离线";

  return (
    <p
      className={`sticker ${ok ? "bg-fresh text-white" : serverStatus === "checking" ? "bg-grid text-ink" : "bg-spoiled text-white"}`}
      role="status"
      aria-live="polite"
    >
      <span aria-hidden className="inline-block size-2 rounded-full bg-white" />
      {text}
    </p>
  );
}
