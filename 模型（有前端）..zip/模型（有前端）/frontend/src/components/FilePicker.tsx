"use client";

import { forwardRef } from "react";

interface Props {
  onFile(file: File): void;
}

/** 隐藏的文件输入，由按钮或拖拽区触发。 */
export const FilePicker = forwardRef<HTMLInputElement, Props>(function FilePicker({ onFile }, ref) {
  return (
    <input
      ref={ref}
      type="file"
      accept=".csv,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
      className="sr-only"
      tabIndex={-1}
      aria-hidden
      onChange={(e) => {
        const f = e.target.files?.[0];
        if (f) onFile(f);
        e.target.value = "";
      }}
    />
  );
});
