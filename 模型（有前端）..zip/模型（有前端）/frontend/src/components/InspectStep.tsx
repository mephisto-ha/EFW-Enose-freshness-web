"use client";

import meta from "@/data/model-meta.json";
import { CLASS_TEXT } from "@/lib/classes";
import { durationLabel, num } from "@/lib/format";
import type { InspectResult } from "@/lib/schema";
import { STRIDE_OPTIONS, useWorkspace } from "@/store/workspace";

import { Segmented } from "./Segmented";

function Check({ ok = true, label, children }: { ok?: boolean; label: string; children: React.ReactNode }) {
  return (
    <li className="grid grid-cols-[2rem_7rem_1fr] items-start gap-3 border-b-2 border-dashed border-rule py-3 last:border-b-0">
      <span
        aria-label={ok ? "通过" : "提示"}
        className={`grid size-7 place-items-center rounded-full border-2 border-ink text-sm font-bold ${ok ? "bg-fresh text-white" : "bg-semi text-ink"}`}
      >
        {ok ? "✓" : "!"}
      </span>
      <span className="pt-0.5 font-semibold">{label}</span>
      <span className="pt-0.5 text-ink-2">{children}</span>
    </li>
  );
}

/** 第 2 步：数据核验。只解析校验，不跑模型，让用户确认交上来的数据。 */
export function InspectStep({ inspection }: { inspection: InspectResult }) {
  const { stride, engine, status, serverStatus, setStride, setEngine, setSheet, confirm, back } =
    useWorkspace();
  const loading = status === "loading";
  const i = inspection;
  const names = meta.class_names;

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
      <section aria-labelledby="ins-title" className="panel p-6">
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <h1 id="ins-title" className="text-[2.25rem] leading-tight">
            数据核验
          </h1>
          <span className="sticker rotate-2 bg-semi text-ink" title={i.file_name}>
            <span className="max-w-[18ch] truncate">{i.file_name}</span>
          </span>
        </div>
        <p className="mt-1 text-ink-2">模型还没开始判断。先确认交上来的数据是不是你想检测的那份。</p>

        <ul className="mt-4">
          <Check label="传感器列">11 / 11 列齐全</Check>
          <Check label="数据量">
            <span className="numeral text-lg text-ink">{i.rows}</span> 行，{durationLabel(i.duration_minutes)}
          </Check>
          <Check label="新鲜基线">前 {i.baseline_len} 行，用来校正传感器漂移</Check>
          <Check label="判定窗口">
            每 {i.win} 分钟判一次，每隔 {i.stride} 分钟出一个结果，共{" "}
            <span className="numeral text-lg text-ink">{i.n_windows}</span> 个；第{" "}
            {num(i.first_judgement_minute)} 分钟出第一个
          </Check>
          <Check ok={i.minute_column !== null} label="时间轴">
            {i.minute_column ? `使用「${i.minute_column}」列` : "没有 minute 列，按行号计时（每行一分钟）"}
          </Check>
          <Check ok={i.truth_counts !== null} label="真实标签">
            {i.truth_counts ? (
              <>
                「{i.label_column}」列：
                {names.map((n, c) => (
                  <span key={n} className="mr-2">
                    <span className={CLASS_TEXT[c]}>{n}</span> {i.truth_counts![c]} 行
                  </span>
                ))}
                {i.cut_column && <>，含部位列「{i.cut_column}」</>}
              </>
            ) : (
              "未提供，不影响判定；提供后可对照模型是否判对"
            )}
          </Check>
          {i.warnings.map((w) => (
            <Check key={w} ok={false} label="注意">
              {w}
            </Check>
          ))}
        </ul>
      </section>

      <div className="space-y-6">
        <section aria-labelledby="pv-title" className="panel overflow-hidden">
          <h2 id="pv-title" className="border-b-2 border-ink bg-pink px-5 py-2.5 text-xl text-white">
            前 5 行读数
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-ink bg-grid">
                  <th className="px-3 py-1.5 text-left font-semibold">行</th>
                  {i.sensors.map((s) => (
                    <th key={s} className="numeral px-2 py-1.5 text-right text-base">
                      {s}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {i.preview.map((row, r) => (
                  <tr key={r} className="border-b border-rule last:border-b-0">
                    <td className="px-3 py-1.5 text-ink-3">{r + 1}</td>
                    {row.map((v, c) => (
                      <td key={c} className="px-2 py-1.5 text-right tabular-nums">
                        {num(v)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section aria-label="检测设置" className="panel space-y-4 p-5">
          {i.sheets.length > 1 && (
            <label className="flex items-center gap-3 text-sm">
              <span className="text-ink-2">工作表</span>
              <select
                value={i.sheet ?? ""}
                onChange={(e) => void setSheet(e.target.value)}
                disabled={loading}
                className="rounded-full border-2 border-ink bg-surface px-3 py-1 font-semibold"
              >
                {i.sheets.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </label>
          )}
          <Segmented
            label="步长"
            value={stride}
            disabled={loading}
            options={STRIDE_OPTIONS.map((s) => ({ value: s, label: `${s} 分钟` }))}
            onChange={(v) => void setStride(v)}
          />
          <Segmented
            label="引擎"
            value={engine}
            disabled={loading}
            options={[
              {
                value: "server",
                label: "服务器",
                title:
                  serverStatus === "offline" ? "推理服务未连接，点击会重新尝试" : "FastAPI + onnxruntime",
              },
              { value: "browser", label: "浏览器", title: "onnxruntime-web，在本机运行，仅支持 CSV" },
            ]}
            onChange={(v) => void setEngine(v)}
          />
        </section>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => void confirm()}
            disabled={loading}
            className="btn btn-primary px-7 py-3 text-lg"
          >
            {loading ? "正在判定…" : "开始判定"}
          </button>
          <button type="button" onClick={back} disabled={loading} className="btn btn-plain">
            重新提交
          </button>
        </div>
      </div>
    </div>
  );
}
