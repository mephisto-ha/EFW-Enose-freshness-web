"use client";

interface Props {
  tone?: "info" | "error";
  title?: string;
  children: React.ReactNode;
  onDismiss?(): void;
}

export function Notice({ tone = "info", title, children, onDismiss }: Props) {
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={`flex items-start gap-3 rounded-2xl border-2 border-ink px-4 py-3 text-sm shadow-[3px_3px_0_var(--ink)] ${
        tone === "error" ? "bg-spoiled text-white" : "bg-surface"
      }`}
    >
      <span aria-hidden className={`mt-0.5 text-base ${tone === "error" ? "" : "text-cobalt"}`}>
        {tone === "error" ? "✕" : "✦"}
      </span>
      <div className="min-w-0 flex-1">
        {title && <p className="font-semibold">{title}</p>}
        <div className={tone === "error" ? "text-white/95" : "text-ink-2"}>{children}</div>
      </div>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          className="shrink-0 rounded-full px-1.5 opacity-70 hover:opacity-100"
          aria-label="关闭提示"
        >
          ✕
        </button>
      )}
    </div>
  );
}
