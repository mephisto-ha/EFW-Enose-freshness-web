"use client";

import { CLASS_BG, CLASS_TEXT } from "@/lib/classes";
import { num, pct } from "@/lib/format";
import type { AnalysisResult } from "@/lib/schema";

interface Props {
  result: AnalysisResult;
  selected: number;
  onStep(delta: number): void;
}

/** 选中窗口的读数面板。 */
export function Readout({ result, selected, onStep }: Props) {
  const w = result.windows[selected];
  const names = result.model.class_names;
  const total = result.windows.length;

  return (
    <section aria-labelledby="readout-title" className="rounded-2xl border-2 border-ink bg-grid px-5 py-5">
      <div className="flex items-baseline justify-between gap-3 text-sm text-ink-2">
        <h3 id="readout-title" className="font-semibold">
          第 {num(w.minute_start)}–{num(w.minute_end)} 分钟
        </h3>
        <span className="numeral text-base text-ink-3">
          {selected + 1} / {total}
        </span>
      </div>

      <p className={`font-display mt-3 text-[3.5rem] leading-none ${CLASS_TEXT[w.pred]}`}>{names[w.pred]}</p>

      <p className="mt-3 flex items-baseline gap-2">
        <span className="text-sm text-ink-2">置信度</span>
        <span className="numeral text-[2.25rem] leading-none">{pct(w.confidence)}</span>
      </p>

      <dl className="mt-4 space-y-2">
        {names.map((n, c) => (
          <div key={n} className="grid grid-cols-[3.5rem_1fr_3rem] items-center gap-2 text-sm">
            <dt className={c === w.pred ? "font-semibold" : "text-ink-2"}>{n}</dt>
            <dd className="h-3 overflow-hidden rounded-full border-2 border-ink bg-surface" aria-hidden>
              <div
                className={`h-full ${CLASS_BG[c]} transition-[width] duration-200 ease-out`}
                style={{ width: `${w.probs[c] * 100}%` }}
              />
            </dd>
            <dd className="numeral text-right">{pct(w.probs[c], 1)}</dd>
          </div>
        ))}
      </dl>

      {w.truth !== null && (
        <p className="mt-4 border-t-2 border-dashed border-rule pt-3 text-sm text-ink-2">
          真实标签 <span className={`font-semibold ${CLASS_TEXT[w.truth]}`}>{names[w.truth]}</span>
          <span className="ml-2">{w.truth === w.pred ? "与判定一致" : "与判定不一致"}</span>
        </p>
      )}

      <div className="mt-5 flex gap-2">
        <button
          type="button"
          onClick={() => onStep(-1)}
          disabled={selected === 0}
          className="btn btn-plain flex-1 justify-center px-2 py-1 text-sm"
        >
          上一个窗口
        </button>
        <button
          type="button"
          onClick={() => onStep(1)}
          disabled={selected === total - 1}
          className="btn btn-plain flex-1 justify-center px-2 py-1 text-sm"
        >
          下一个窗口
        </button>
      </div>
      <p className="mt-2 text-xs text-ink-3">在时间轴上点选任意时刻，或用键盘左右方向键切换。</p>
    </section>
  );
}
