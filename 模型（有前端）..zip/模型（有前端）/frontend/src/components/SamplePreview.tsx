import preview from "@/data/sample-preview.json";
import { classColor } from "@/lib/classes";

/** 示例色带：参考脚本对示例数据的真实输出，不是示意图。 */
export function SamplePreview({ compact = false }: { compact?: boolean }) {
  const total = 380;
  const first = preview[0].end - 10;
  return (
    <figure className="w-full">
      <div
        className={`flex w-full overflow-hidden rounded-xl border-2 border-ink ${compact ? "h-8" : "h-12"}`}
        aria-hidden
      >
        <div
          className="stripes-cobalt h-full bg-surface opacity-60"
          style={{ width: `${(first / total) * 100}%` }}
        />
        {preview.map((p) => (
          <div
            key={p.end}
            className="h-full"
            style={{
              width: `${(10 / total) * 100}%`,
              background: classColor(p.pred),
              opacity: 0.35 + 0.65 * Math.max(0, (p.conf - 1 / 3) / (2 / 3)),
            }}
          />
        ))}
      </div>
      {!compact && (
        <figcaption className="mt-2 text-sm text-ink-2">
          示例的真实判定：第 80 分钟起新鲜，第 210 分钟起次新鲜，第 370 分钟起腐败。
        </figcaption>
      )}
    </figure>
  );
}
