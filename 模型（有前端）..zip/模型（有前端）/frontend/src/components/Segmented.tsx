"use client";

import { useId } from "react";

interface Option<T extends string | number> {
  value: T;
  label: string;
  disabled?: boolean;
  title?: string;
}

interface Props<T extends string | number> {
  label: string;
  value: T;
  options: Option<T>[];
  onChange(value: T): void;
  disabled?: boolean;
}

/** 分段选择（单选按钮组），键盘用 Tab 进入、←/→ 切换。 */
export function Segmented<T extends string | number>({
  label,
  value,
  options,
  onChange,
  disabled,
}: Props<T>) {
  const id = useId();
  return (
    <fieldset className="flex items-center gap-2" disabled={disabled}>
      <legend className="sr-only">{label}</legend>
      <span aria-hidden className="text-sm font-semibold text-ink-2">
        {label}
      </span>
      <div className="flex rounded-full border-2 border-ink bg-surface p-0.5">
        {options.map((o) => {
          const checked = o.value === value;
          return (
            <label
              key={String(o.value)}
              title={o.title}
              className={`relative cursor-pointer rounded-full px-3 py-0.5 text-sm font-semibold transition-colors has-[:focus-visible]:outline-3 has-[:focus-visible]:outline-focus ${
                checked ? "bg-cobalt text-white" : "text-ink-2 hover:text-ink"
              } ${o.disabled ? "cursor-not-allowed opacity-40" : ""}`}
            >
              <input
                type="radio"
                name={id}
                value={String(o.value)}
                checked={checked}
                disabled={o.disabled}
                onChange={() => onChange(o.value)}
                className="sr-only"
              />
              {o.label}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
