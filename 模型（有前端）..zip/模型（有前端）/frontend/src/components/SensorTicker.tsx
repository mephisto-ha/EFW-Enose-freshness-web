import { SENSOR_GASES } from "@/data/sensors";

/** 页头下方的跑马灯：11 个「鼻子」各闻什么。减少动态效果时静止。 */
export function SensorTicker() {
  const items = Object.entries(SENSOR_GASES);
  const row = (key: string) => (
    <ul key={key} className="flex shrink-0 items-center" aria-hidden={key === "b"}>
      {items.map(([s, g]) => (
        <li key={s} className="flex items-center gap-2 px-4 text-sm">
          <span className="numeral text-base text-semi">{s}</span>
          <span className="text-paper/90">{g}</span>
          <span aria-hidden className="pl-4 text-pink">
            ✦
          </span>
        </li>
      ))}
    </ul>
  );
  return (
    <div className="overflow-hidden border-b-2 border-ink bg-ink py-1.5" aria-label="11 路传感器与其敏感气体">
      <div className="marquee-track flex w-max">
        {row("a")}
        {row("b")}
      </div>
    </div>
  );
}
