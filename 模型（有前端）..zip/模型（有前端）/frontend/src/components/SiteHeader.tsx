"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { EngineStatus } from "./EngineStatus";
import { SensorTicker } from "./SensorTicker";

const NAV = [
  { href: "/", label: "检测" },
  { href: "/model", label: "模型说明" },
];

export function SiteHeader() {
  const pathname = usePathname();
  return (
    <header>
      <div aria-hidden className="stripes h-2.5 border-b-2 border-ink" />
      <div className="flex flex-wrap items-center gap-x-8 gap-y-2 border-b-2 border-ink bg-surface px-5 py-3 sm:px-8">
        <Link href="/" className="flex items-center gap-3">
          <span
            aria-hidden
            className="grid size-10 -rotate-6 place-items-center rounded-full border-2 border-ink bg-pink text-lg text-white shadow-[2px_2px_0_var(--ink)]"
          >
            <span className="font-display">鼻</span>
          </span>
          <span className="font-display text-xl leading-none sm:text-2xl">电子鼻牛肉新鲜度检测台</span>
        </Link>
        <nav aria-label="主导航" className="flex gap-2">
          {NAV.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`rounded-full border-2 px-3.5 py-0.5 text-sm font-semibold transition-colors ${
                  active
                    ? "border-ink bg-semi text-ink shadow-[2px_2px_0_var(--ink)]"
                    : "border-transparent text-ink-2 hover:border-ink"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="ml-auto">
          <EngineStatus />
        </div>
      </div>
      <SensorTicker />
    </header>
  );
}
