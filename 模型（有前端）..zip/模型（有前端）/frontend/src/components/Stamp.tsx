import { classColor } from "@/lib/classes";

/** 检疫章风格的判定印章：双圈边框 + 磨损纹理。 */
export function Stamp({
  label,
  sub,
  cls,
  animate = true,
}: {
  label: string;
  sub: string;
  cls: number;
  animate?: boolean;
}) {
  const color = classColor(cls);
  const id = `wear-${cls}`;
  return (
    <svg
      viewBox="0 0 260 260"
      className={`w-full max-w-[280px] ${animate ? "stamp-in" : "-rotate-[8deg]"}`}
      role="img"
      aria-label={`判定印章：${label}`}
    >
      <defs>
        <filter id={id}>
          <feTurbulence type="fractalNoise" baseFrequency="1.1" numOctaves="2" seed={cls + 3} result="n" />
          <feColorMatrix
            in="n"
            type="matrix"
            values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.5 1.72"
            result="m"
          />
          <feComposite in="SourceGraphic" in2="m" operator="in" />
        </filter>
        <path id="ring-top" d="M 40 130 A 90 90 0 0 1 220 130" />
        <path id="ring-bottom" d="M 32 130 A 98 98 0 0 0 228 130" />
      </defs>
      <g filter={`url(#${id})`} fill="none" stroke={color}>
        <circle cx="130" cy="130" r="122" strokeWidth="8" />
        <circle cx="130" cy="130" r="106" strokeWidth="3" />
        <text
          fill={color}
          stroke="none"
          fontSize="17"
          fontWeight="700"
          letterSpacing="6"
          style={{ fontFamily: "var(--font-display)" }}
        >
          <textPath href="#ring-top" startOffset="50%" textAnchor="middle">
            电子鼻检测
          </textPath>
        </text>
        <text
          fill={color}
          stroke="none"
          fontSize="15"
          letterSpacing="3"
          style={{ fontFamily: "var(--font-numeral)", fontWeight: 800 }}
        >
          <textPath href="#ring-bottom" startOffset="50%" textAnchor="middle">
            {sub}
          </textPath>
        </text>
        <rect x="34" y="96" width="192" height="68" rx="6" fill={color} stroke="none" />
        <text
          x="130"
          y="146"
          textAnchor="middle"
          fill="#fff"
          stroke="none"
          fontSize={label.length > 2 ? 46 : 54}
          style={{ fontFamily: "var(--font-display)" }}
        >
          {label}
        </text>
      </g>
    </svg>
  );
}
