"use client";

import type { Step } from "@/store/workspace";

const STEPS: { key: Step; label: string }[] = [
  { key: "submit", label: "提交数据" },
  { key: "inspect", label: "数据核验" },
  { key: "result", label: "判定结果" },
];

/** 三步流程指示。已完成的步骤可以点回去。 */
export function StepNav({ step, onGo }: { step: Step; onGo(step: Step): void }) {
  const current = STEPS.findIndex((s) => s.key === step);
  return (
    <nav aria-label="检测步骤">
      <ol className="flex flex-wrap items-center gap-2 sm:gap-3">
        {STEPS.map((s, i) => {
          const done = i < current;
          const active = i === current;
          const cls = active
            ? "bg-cobalt text-white shadow-[3px_3px_0_var(--ink)]"
            : done
              ? "bg-semi text-ink hover:-translate-y-px"
              : "bg-surface text-ink-3";
          const body = (
            <>
              <span
                className={`numeral grid size-7 place-items-center rounded-full border-2 border-ink text-base ${active ? "bg-white text-cobalt" : "bg-surface text-ink"}`}
              >
                {done ? "✓" : i + 1}
              </span>
              <span className="font-display text-lg leading-none">{s.label}</span>
            </>
          );
          return (
            <li key={s.key} className="flex items-center gap-2 sm:gap-3">
              {done ? (
                <button
                  type="button"
                  onClick={() => onGo(s.key)}
                  className={`flex items-center gap-2 rounded-full border-2 border-ink py-1 pl-1 pr-4 transition-transform ${cls}`}
                >
                  {body}
                </button>
              ) : (
                <span
                  aria-current={active ? "step" : undefined}
                  className={`flex items-center gap-2 rounded-full border-2 border-ink py-1 pl-1 pr-4 ${cls}`}
                >
                  {body}
                </span>
              )}
              {i < STEPS.length - 1 && (
                <span aria-hidden className="hidden h-0.5 w-6 bg-ink sm:block">
                  {""}
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
