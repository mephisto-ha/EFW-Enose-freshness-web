"use client";

import { useRef, useState, type DragEvent } from "react";

import { SENSOR_GASES, SPOILAGE_SENSORS, STICKER_COLORS } from "@/data/sensors";
import { useWorkspace } from "@/store/workspace";

import { FilePicker } from "./FilePicker";
import { SamplePreview } from "./SamplePreview";

/** 第 1 步：提交数据。三种方式：上传文件、粘贴表格、示例数据。 */
export function SubmitStep() {
  const submit = useWorkspace((s) => s.submit);
  const status = useWorkspace((s) => s.status);
  const engine = useWorkspace((s) => s.engine);
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [pasted, setPasted] = useState("");
  const loading = status === "loading";

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files?.[0];
    if (f) void submit({ kind: "file", file: f });
  };

  const submitPasted = () => {
    const file = new File([pasted], "粘贴的数据.csv", { type: "text/csv" });
    void submit({ kind: "file", file });
  };

  return (
    <div>
      {/* 主标题与信息贴纸 */}
      <div className="relative">
        <h1 className="text-[2.75rem] leading-[1.05] sm:text-[4.5rem]">
          这块牛肉，
          <br />
          还新鲜吗？
        </h1>
        <p className="mt-5 max-w-[56ch] text-lg text-ink-2">
          交上一段电子鼻读数，模型逐段闻一闻，告诉你它是新鲜、次新鲜还是已经腐败。数据只在本次检测中使用，不会保存。
        </p>
        <ul className="mt-5 flex flex-wrap gap-3" aria-label="检测规格">
          <li className="sticker -rotate-2 bg-semi text-ink">11 路气体传感器</li>
          <li className="sticker rotate-1 bg-pink text-white">每次读 60 分钟</li>
          <li className="sticker -rotate-1 bg-fresh text-white">新鲜 / 次新鲜 / 腐败</li>
          <li className="sticker rotate-2 bg-surface text-ink">最少 80 行数据</li>
        </ul>
      </div>

      {/* 三种提交方式 */}
      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        <section
          aria-labelledby="up-title"
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          className={`panel relative overflow-hidden bg-cobalt p-6 text-white transition-transform ${dragging ? "-rotate-1 scale-[1.01]" : ""}`}
        >
          <div aria-hidden className="dots-light absolute inset-0" />
          <div className="relative">
            <h2 id="up-title" className="text-[1.75rem] leading-tight">
              上传文件
            </h2>
            <p className="mt-2 text-sm text-white/85">
              拖进这个框，或点下面的按钮。{engine === "browser" ? "CSV" : "CSV 或 Excel（可多工作表）"}，10 MB
              以内。
            </p>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              disabled={loading}
              className="btn btn-plain mt-5"
            >
              选择文件
            </button>
            <FilePicker ref={inputRef} onFile={(file) => void submit({ kind: "file", file })} />
          </div>
        </section>

        <section aria-labelledby="paste-title" className="panel bg-semi p-6">
          <h2 id="paste-title" className="text-[1.75rem] leading-tight">
            粘贴表格
          </h2>
          <label htmlFor="paste" className="mt-2 block text-sm text-ink-2">
            在 Excel 里选中整张表（含表头）复制，粘贴到这里。
          </label>
          <textarea
            id="paste"
            value={pasted}
            onChange={(e) => setPasted(e.target.value)}
            rows={4}
            spellCheck={false}
            placeholder={"minute\tMQ135\tMQ136\t…\n1\t17.4\t14.77\t…"}
            className="mt-3 w-full resize-y rounded-xl border-2 border-ink bg-surface px-3 py-2 font-mono text-xs leading-5"
          />
          <button
            type="button"
            onClick={submitPasted}
            disabled={loading || pasted.trim().length === 0}
            className="btn btn-plain mt-3"
          >
            提交粘贴的数据
          </button>
        </section>

        <section aria-labelledby="sample-title" className="panel bg-pink p-6 text-white">
          <h2 id="sample-title" className="text-[1.75rem] leading-tight">
            先试试示例
          </h2>
          <p className="mt-2 text-sm text-white/90">
            380 分钟，由公开数据集两个部位的片段拼接，三类各两段，带真实标签。曲线上的台阶是拼接处。
          </p>
          <div className="mt-4 rounded-xl bg-surface p-2.5 text-ink">
            <SamplePreview compact />
          </div>
          <button
            type="button"
            onClick={() => void submit({ kind: "sample" })}
            disabled={loading}
            className="btn btn-plain mt-4"
          >
            {loading ? "正在读取…" : "载入示例数据"}
          </button>
        </section>
      </div>

      {/* 数据格式要求 */}
      <section aria-labelledby="fmt-title" className="panel mt-10 p-6">
        <h2 id="fmt-title" className="text-[1.6rem]">
          数据要长这样
        </h2>
        <p className="mt-2 max-w-[72ch] text-ink-2">
          每行一分钟，表头包含下面 11 个传感器列（不分大小写），至少 80 行。前 20
          行会被当作新鲜基线，用来校正传感器漂移。可选 minute 列（时间轴）和 true_label
          列（用于和真实标签对照）。
        </p>
        <ul className="mt-5 flex flex-wrap gap-x-3 gap-y-3" aria-label="11 路传感器及敏感气体">
          {Object.entries(SENSOR_GASES).map(([s, g], i) => (
            <li
              key={s}
              className={`sticker ${STICKER_COLORS[i % STICKER_COLORS.length]} ${i % 3 === 0 ? "-rotate-2" : i % 3 === 1 ? "rotate-1" : "-rotate-1"}`}
            >
              <span className="numeral text-base">{s}</span>
              <span className="font-normal">{g}</span>
              {SPOILAGE_SENSORS.has(s) && (
                <span aria-label="与变质最相关" title="与变质最相关">
                  ★
                </span>
              )}
            </li>
          ))}
        </ul>
        <p className="mt-4 text-xs text-ink-3">★ 肉类变质主要释放氨、硫化氢和醛类，这几路传感器最敏感。</p>
      </section>
    </div>
  );
}
