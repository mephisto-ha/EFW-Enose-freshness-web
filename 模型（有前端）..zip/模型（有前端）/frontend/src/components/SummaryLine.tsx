import { CLASS_TEXT } from "@/lib/classes";
import { durationLabel, num } from "@/lib/format";
import type { AnalysisResult } from "@/lib/schema";

/** 页面的结论句：模型在第几分钟首次判为次新鲜 / 腐败。 */
export function SummaryLine({ result }: { result: AnalysisResult }) {
  const { summary, model, series } = result;
  const names = model.class_names;
  const span = series.minute[series.minute.length - 1] - series.minute[0] + 1;
  const events = [1, 2]
    .filter((c) => summary.first_minute[c] !== null)
    .map((c) => ({ c, m: summary.first_minute[c] as number }));

  return (
    <div className="max-w-[60ch]">
      <h2 id="process-title" className="text-[1.6rem] leading-snug sm:text-[2rem]">
        {durationLabel(span)}的读数中，
        {events.length === 0 ? (
          <>
            所有窗口都判为<span className={`whitespace-nowrap ${CLASS_TEXT[0]}`}>{names[0]}</span>。
          </>
        ) : (
          events.map((e, i) => (
            <span key={e.c}>
              {i > 0 && "，"}第 {num(e.m)} 分钟首次判为
              <span className={`whitespace-nowrap ${CLASS_TEXT[e.c]}`}>{names[e.c]}</span>
            </span>
          ))
        )}
        {events.length > 0 && "。"}
      </h2>
      {summary.agreement && summary.agreement.total > 0 && (
        <p className="mt-2 text-sm text-ink-2">
          与文件中的真实标签对照，{summary.agreement.matched} / {summary.agreement.total} 个窗口一致（
          {Math.round((summary.agreement.matched / summary.agreement.total) * 100)}
          %，按每个窗口最后一分钟的标签计）。
        </p>
      )}
    </div>
  );
}
