"use client";

import { downloadText, exportFileName, predictionsCsv } from "@/lib/export";
import type { AnalysisResult } from "@/lib/schema";
import { STRIDE_OPTIONS, useWorkspace } from "@/store/workspace";

import { Segmented } from "./Segmented";

export function Toolbar({ result }: { result: AnalysisResult }) {
  const { stride, engine, status, serverStatus, setStride, setEngine, setSheet, back, reset } =
    useWorkspace();
  const loading = status === "loading";
  const { source } = result;

  return (
    <div className="flex flex-wrap items-center gap-x-6 gap-y-3 rounded-2xl border-2 border-ink bg-paper px-4 py-3">
      <div className="flex min-w-0 items-baseline gap-3">
        <p className="truncate font-semibold" title={source.file_name}>
          {source.file_name}
        </p>
        <p className="shrink-0 text-sm text-ink-3">
          {source.rows} 行，{result.windows.length} 个窗口
        </p>
      </div>

      {source.sheets.length > 1 && (
        <label className="flex items-center gap-2 text-sm font-semibold text-ink-2">
          工作表
          <select
            value={source.sheet ?? ""}
            onChange={(e) => void setSheet(e.target.value)}
            disabled={loading}
            className="rounded-full border-2 border-ink bg-surface px-3 py-1 text-sm font-semibold text-ink"
          >
            {source.sheets.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </label>
      )}

      <Segmented
        label="步长"
        value={stride}
        disabled={loading}
        options={STRIDE_OPTIONS.map((s) => ({ value: s, label: `${s} 分钟` }))}
        onChange={(v) => void setStride(v)}
      />

      <Segmented
        label="引擎"
        value={engine}
        disabled={loading}
        options={[
          {
            value: "server",
            label: "服务器",
            title: serverStatus === "offline" ? "推理服务未连接，点击会重新尝试" : "FastAPI + onnxruntime",
          },
          { value: "browser", label: "浏览器", title: "onnxruntime-web，在本机运行，仅支持 CSV" },
        ]}
        onChange={(v) => void setEngine(v)}
      />

      <div className="flex flex-wrap items-center gap-2 xl:ml-auto">
        <button
          type="button"
          onClick={() => downloadText(predictionsCsv(result), exportFileName(result))}
          className="btn btn-primary px-4 py-1 text-sm"
        >
          导出预测 CSV
        </button>
        <button type="button" onClick={back} disabled={loading} className="btn btn-plain px-4 py-1 text-sm">
          回到核验
        </button>
        <button type="button" onClick={reset} disabled={loading} className="btn btn-plain px-4 py-1 text-sm">
          检测另一份
        </button>
      </div>
    </div>
  );
}
