"use client";

import { CLASS_TEXT, classColor } from "@/lib/classes";
import { num, pct } from "@/lib/format";
import type { AnalysisResult } from "@/lib/schema";

import { Stamp } from "./Stamp";

const ANSWERS = [
  { yes: "是，新鲜。", note: "最近 60 分钟的气味特征和新鲜牛肉样本一致。" },
  { yes: "还行，次新鲜。", note: "开始出现变质相关的气味变化，建议尽快处理。" },
  { yes: "否，已腐败。", note: "气味特征已经接近腐败样本。" },
];

/** 第 3 步的开头：直接回答「新鲜吗」。依据是最后一个窗口（最新状态）。 */
export function VerdictHero({ result }: { result: AnalysisResult }) {
  const { windows, model, summary } = result;
  const names = model.class_names;
  const last = windows[windows.length - 1];
  const recent = windows.slice(-3);
  const steady = recent.filter((w) => w.pred === last.pred).length;
  const ans = ANSWERS[last.pred];

  return (
    <section aria-labelledby="verdict-title" className="panel relative overflow-hidden">
      <div
        aria-hidden
        className="absolute inset-y-0 left-0 w-3"
        style={{ background: classColor(last.pred) }}
      />
      <div className="grid items-center gap-6 p-6 pl-9 md:grid-cols-[minmax(0,1fr)_260px] md:p-8 md:pl-12">
        <div>
          <p className="text-ink-2">这块牛肉新鲜吗？</p>
          <h1
            id="verdict-title"
            className={`mt-1 text-[3rem] leading-none sm:text-[4.5rem] ${CLASS_TEXT[last.pred]}`}
          >
            {ans.yes}
          </h1>
          <p className="mt-4 max-w-[52ch] text-lg">{ans.note}</p>

          <dl className="mt-6 flex flex-wrap gap-3">
            <div className="sticker -rotate-1 bg-surface py-1 text-ink">
              <dt className="font-normal text-ink-2">置信度</dt>
              <dd className="numeral text-xl">{pct(last.confidence)}</dd>
            </div>
            <div className="sticker rotate-1 bg-surface py-1 text-ink">
              <dt className="font-normal text-ink-2">最近 3 次判定</dt>
              <dd className="flex gap-1">
                {recent.map((w) => (
                  <span
                    key={w.index}
                    title={names[w.pred]}
                    className="size-4 rounded-full border-2 border-ink"
                    style={{ background: classColor(w.pred) }}
                  />
                ))}
              </dd>
              <dd className="font-normal text-ink-2">{steady === 3 ? "一致" : `${steady} 次相同`}</dd>
            </div>
            {[1, 2].map((c) =>
              summary.first_minute[c] !== null ? (
                <div
                  key={c}
                  className={`sticker ${c === 1 ? "-rotate-2 bg-semi text-ink" : "rotate-2 bg-spoiled text-white"}`}
                >
                  <dt className="font-normal">首次{names[c]}</dt>
                  <dd className="numeral text-xl">第 {num(summary.first_minute[c] as number)} 分钟</dd>
                </div>
              ) : null,
            )}
          </dl>
          <p className="mt-5 text-xs text-ink-3">
            依据第 {num(last.minute_start)}–{num(last.minute_end)}{" "}
            分钟的读数（最后一个窗口）。研究演示，不作为食品安全判定依据。
          </p>
        </div>
        <div className="mx-auto w-[220px] md:w-full">
          <Stamp
            key={`${result.source.file_name}-${result.source.sheet}-${last.pred}`}
            label={names[last.pred]}
            sub={`CONF ${pct(last.confidence)}`}
            cls={last.pred}
          />
        </div>
      </div>
    </section>
  );
}
