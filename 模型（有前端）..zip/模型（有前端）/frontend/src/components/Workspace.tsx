"use client";

import { useWorkspace, type Step } from "@/store/workspace";

import { CompensationGrid } from "./charts/CompensationGrid";
import { Timeline } from "./charts/Timeline";
import { InspectStep } from "./InspectStep";
import { Notice } from "./Notice";
import { Readout } from "./Readout";
import { Segmented } from "./Segmented";
import { StepNav } from "./StepNav";
import { SubmitStep } from "./SubmitStep";
import { SummaryLine } from "./SummaryLine";
import { Toolbar } from "./Toolbar";
import { VerdictHero } from "./VerdictHero";

export function Workspace() {
  const s = useWorkspace();
  const { step, result, inspection, status, error, notice } = s;
  const loading = status === "loading";

  const goTo = (target: Step) => {
    if (target === "submit") s.reset();
    else if (target === "inspect" && step === "result") s.back();
  };

  return (
    <div className="mx-auto max-w-[1320px] px-5 pb-6 pt-8 sm:px-8">
      <StepNav step={step} onGo={goTo} />

      <div className="mt-6 space-y-3 empty:hidden">
        {notice && <Notice onDismiss={s.dismissNotice}>{notice}</Notice>}
        {status === "error" && error && (
          <Notice tone="error" title={step === "submit" ? "这份数据没法检测" : "这一步没有完成"}>
            {error.message}
          </Notice>
        )}
      </div>

      <div className="mt-8">
        {step === "submit" && <SubmitStep />}
        {step === "inspect" && inspection && <InspectStep inspection={inspection} />}
        {step === "result" && result && (
          <div className={`space-y-8 transition-opacity ${loading ? "opacity-60" : ""}`} aria-busy={loading}>
            <VerdictHero result={result} />

            {result.warnings.length > 0 && (
              <div className="space-y-2">
                {result.warnings.map((w) => (
                  <Notice key={w}>{w}</Notice>
                ))}
              </div>
            )}

            <section aria-labelledby="process-title" className="panel p-5 sm:p-7">
              <SummaryLine result={result} />
              <div className="mt-5">
                <Toolbar result={result} />
              </div>

              <div className="mt-6 grid gap-8 lg:grid-cols-[300px_minmax(0,1fr)]">
                <div className="lg:sticky lg:top-6 lg:self-start">
                  <Readout result={result} selected={s.selected} onStep={s.stepWindow} />
                  <p className="mt-3 px-1 text-xs text-ink-3">
                    {result.source.engine === "server" ? "服务器推理" : "浏览器推理"}，用时{" "}
                    {result.elapsed_ms.toFixed(0)} ms
                  </p>
                </div>
                <div className="min-w-0">
                  <div className="mb-4 flex flex-wrap items-center gap-x-6 gap-y-2">
                    <Segmented
                      label="传感器曲线"
                      value={s.laneMode}
                      options={[
                        { value: "raw", label: "各自缩放" },
                        { value: "relative", label: "统一刻度 %" },
                      ]}
                      onChange={s.setLaneMode}
                    />
                    <p className="text-xs text-ink-3">
                      {s.laneMode === "raw"
                        ? "每路按自己的范围缩放，看形状变化"
                        : "所有通道同一纵轴（相对基线 %），看谁变化最大"}
                      ；点传感器名可放大，斜纹为基线段。
                    </p>
                  </div>
                  <Timeline
                    result={result}
                    selected={s.selected}
                    onSelect={s.select}
                    laneMode={s.laneMode}
                    focusedLane={s.focusedLane}
                    onFocusLane={s.setFocusedLane}
                  />
                </div>
              </div>
            </section>

            <section className="panel p-5 sm:p-7">
              <CompensationGrid result={result} selected={s.selected} />
            </section>
          </div>
        )}
      </div>
    </div>
  );
}
