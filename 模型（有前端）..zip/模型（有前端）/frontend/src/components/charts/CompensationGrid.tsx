"use client";

import { scaleLinear } from "d3-scale";
import { line } from "d3-shape";
import { useMemo } from "react";

import { num } from "@/lib/format";
import type { AnalysisResult } from "@/lib/schema";

import { useElementWidth } from "../useElementWidth";

const H = 64;

function Mini({ name, raw, comp, width }: { name: string; raw: number[]; comp: number[]; width: number }) {
  const { dRaw, dComp, lo, hi } = useMemo(() => {
    const all = raw.concat(comp);
    const lo = Math.min(...all);
    const hi = Math.max(...all);
    const pad = (hi - lo) * 0.1 || 0.5;
    const x = scaleLinear()
      .domain([0, raw.length - 1])
      .range([1, width - 1]);
    const y = scaleLinear()
      .domain([lo - pad, hi + pad])
      .range([H - 2, 2]);
    const l = line<number>()
      .x((_, i) => x(i))
      .y((v) => y(v));
    return { dRaw: l(raw) ?? "", dComp: l(comp) ?? "", lo, hi };
  }, [raw, comp, width]);

  const meanShift =
    comp.reduce((a, b) => a + b, 0) / comp.length - raw.reduce((a, b) => a + b, 0) / raw.length;

  return (
    <figure>
      <figcaption className="flex items-baseline justify-between text-xs">
        <span className="numeral text-sm">{name}</span>
        <span className="numeral text-ink-3" title="补偿后均值 − 原始均值">
          {meanShift >= 0 ? "+" : ""}
          {meanShift.toFixed(2)}
        </span>
      </figcaption>
      <svg
        width={width}
        height={H}
        className="mt-1 block bg-surface"
        role="img"
        aria-label={`${name}：原始读数 ${num(lo)} 到 ${num(hi)}`}
      >
        <path d={dRaw} fill="none" stroke="var(--ink-3)" strokeWidth={1} strokeDasharray="3 2" />
        <path d={dComp} fill="none" stroke="var(--ink)" strokeWidth={1.3} />
      </svg>
    </figure>
  );
}

/** 所选窗口 11 路「原始 vs 补偿后」小图（模型输出 compensated_raw）。 */
export function CompensationGrid({ result, selected }: { result: AnalysisResult; selected: number }) {
  const [ref, width] = useElementWidth<HTMLDivElement>();
  const w = result.windows[selected];
  const comp = result.compensated?.[selected];
  const cols = width >= 1000 ? 6 : width >= 700 ? 4 : width >= 440 ? 3 : 2;
  const gap = 16;
  const cellW = Math.max(60, Math.floor((width - gap * (cols - 1)) / cols));

  return (
    <section aria-labelledby="comp-title">
      <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
        <h2 id="comp-title" className="text-[1.6rem]">
          漂移补偿：第 {num(w.minute_start)}–{num(w.minute_end)} 分钟
        </h2>
        <p className="flex items-center gap-4 text-xs text-ink-2">
          <span className="flex items-center gap-1.5">
            <svg width="18" height="6" aria-hidden>
              <line x1="0" x2="18" y1="3" y2="3" stroke="var(--ink-3)" strokeDasharray="3 2" />
            </svg>
            原始读数
          </span>
          <span className="flex items-center gap-1.5">
            <svg width="18" height="6" aria-hidden>
              <line x1="0" x2="18" y1="3" y2="3" stroke="var(--ink)" strokeWidth="1.5" />
            </svg>
            补偿后
          </span>
        </p>
      </div>
      <p className="mt-1 max-w-[72ch] text-sm text-ink-2">
        模型先根据开头 20
        分钟的基线估计传感器漂移，把读数校正到训练时的状态再判断。右上角数字是补偿前后的均值差（原始单位）。
      </p>
      <div ref={ref} className="mt-4">
        {comp ? (
          <div className="grid" style={{ gridTemplateColumns: `repeat(${cols}, ${cellW}px)`, gap }}>
            {result.model.sensors.map((s, i) => (
              <Mini
                key={s}
                name={s}
                raw={result.series.values[i].slice(w.start_row - 1, w.end_row)}
                comp={comp[i]}
                width={cellW}
              />
            ))}
          </div>
        ) : (
          <p className="text-sm text-ink-3">本次结果未包含补偿数据。</p>
        )}
      </div>
    </section>
  );
}
