"use client";

import { scaleLinear } from "d3-scale";
import { area, curveMonotoneX, line } from "d3-shape";
import { memo, useCallback, useMemo, useRef, useState, type KeyboardEvent, type PointerEvent } from "react";

import { CLASS_TEXT, classColor } from "@/lib/classes";
import { num, pct } from "@/lib/format";
import type { AnalysisResult } from "@/lib/schema";
import type { LaneMode } from "@/store/workspace";

import { useElementWidth } from "../useElementWidth";

interface Props {
  result: AnalysisResult;
  selected: number;
  onSelect(index: number): void;
  laneMode: LaneMode;
  focusedLane: number | null;
  onFocusLane(lane: number | null): void;
}

interface Track {
  y: number;
  h: number;
}

const PAD_R = 12;

function layout(hasTruth: boolean, nLanes: number, focused: number | null, compact: boolean) {
  let y = 0;
  const band: Track = { y, h: compact ? 30 : 36 };
  y += band.h + 8;
  let truth: Track | null = null;
  if (hasTruth) {
    truth = { y, h: 10 };
    y += truth.h + 14;
  }
  const probs: Track = { y, h: compact ? 56 : 72 };
  y += probs.h + 18;
  const lanesTop = y;
  const base = compact ? 22 : 28;
  const lanes: Track[] = [];
  for (let i = 0; i < nLanes; i++) {
    const h = focused === i ? (compact ? 110 : 150) : base;
    lanes.push({ y, h });
    y += h + 2;
  }
  const lanesBottom = y - 2;
  const axisY = y + 4;
  return { band, truth, probs, lanes, lanesTop, lanesBottom, axisY, height: axisY + 22 };
}

/** 二分查找：minutes 中最接近 m 的下标 */
function nearestRow(minutes: number[], m: number): number {
  let lo = 0;
  let hi = minutes.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (minutes[mid] < m) lo = mid + 1;
    else hi = mid;
  }
  if (lo > 0 && Math.abs(minutes[lo - 1] - m) < Math.abs(minutes[lo] - m)) return lo - 1;
  return lo;
}

export const Timeline = memo(function Timeline({
  result,
  selected,
  onSelect,
  laneMode,
  focusedLane,
  onFocusLane,
}: Props) {
  const [ref, width] = useElementWidth<HTMLDivElement>();
  const compact = width < 640;
  const padL = compact ? 52 : 64;
  const { series, windows, model, truth } = result;
  const minutes = series.minute;
  const names = model.class_names;
  const stride = model.stride;

  const L = useMemo(
    () => layout(truth !== null, model.sensors.length, focusedLane, compact),
    [truth, model.sensors.length, focusedLane, compact],
  );

  const x = useMemo(
    () =>
      scaleLinear()
        .domain([minutes[0], minutes[minutes.length - 1]])
        .range([padL, Math.max(padL + 10, width - PAD_R)]),
    [minutes, padL, width],
  );

  const minuteAt = useCallback(
    (row1: number) => minutes[Math.max(0, Math.min(minutes.length - 1, row1 - 1))],
    [minutes],
  );

  /** 每个判定格覆盖 (end - stride, end] 这几分钟 */
  const cells = useMemo(
    () =>
      windows.map((w) => {
        const x0 = x(minuteAt(w.end_row - stride));
        const x1 = x(minuteAt(w.end_row));
        return { x0, x1, w };
      }),
    [windows, x, minuteAt, stride],
  );

  const warmupEnd = cells.length ? cells[0].x0 : x.range()[1];

  // 各路传感器：相对基线 % 或原始值
  const lanesData = useMemo(() => {
    const bl = model.baseline_len;
    const transformed = series.values.map((vals) => {
      if (laneMode === "raw") return vals;
      let b = 0;
      for (let i = 0; i < bl; i++) b += vals[i];
      b = b / bl || 1e-6;
      return vals.map((v) => Math.max(-500, Math.min(500, ((v - b) / Math.abs(b)) * 100)));
    });
    let gMin = Infinity;
    let gMax = -Infinity;
    const ranges = transformed.map((vals) => {
      let mn = Infinity;
      let mx = -Infinity;
      for (const v of vals) {
        if (v < mn) mn = v;
        if (v > mx) mx = v;
      }
      gMin = Math.min(gMin, mn);
      gMax = Math.max(gMax, mx);
      return [mn, mx] as const;
    });
    return { transformed, ranges, global: [gMin, gMax] as const };
  }, [series.values, laneMode, model.baseline_len]);

  const lanePaths = useMemo(() => {
    return lanesData.transformed.map((vals, i) => {
      const t = L.lanes[i];
      const [mn, mx] = laneMode === "relative" ? lanesData.global : lanesData.ranges[i];
      const pad = (mx - mn) * 0.08 || 1;
      const y = scaleLinear()
        .domain([mn - pad, mx + pad])
        .range([t.y + t.h, t.y]);
      const d = line<number>()
        .x((_, j) => x(minutes[j]))
        .y((v) => y(v))(vals);
      const zero = laneMode === "relative" ? y(0) : null;
      return { d: d ?? "", zero, y, domain: [mn, mx] as const };
    });
  }, [lanesData, L.lanes, laneMode, x, minutes]);

  const probAreas = useMemo(() => {
    const t = L.probs;
    const y = scaleLinear()
      .domain([0, 1])
      .range([t.y + t.h, t.y]);
    const stacks = windows.map((w) => {
      const a = w.probs[0];
      const b = a + w.probs[1];
      return { m: w.minute_end, s: [0, a, b, 1] };
    });
    return [0, 1, 2].map(
      (c) =>
        area<(typeof stacks)[number]>()
          .curve(curveMonotoneX)
          .x((p) => x(p.m))
          .y0((p) => y(p.s[c]))
          .y1((p) => y(p.s[c + 1]))(stacks) ?? "",
    );
  }, [windows, L.probs, x]);

  const ticks = useMemo(() => x.ticks(Math.max(3, Math.floor((width - padL) / 90))), [x, width, padL]);

  // ---------- 交互 ----------
  const [hover, setHover] = useState<{ px: number; row: number } | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const cellAtMinute = useCallback(
    (m: number): number | null => {
      for (let k = 0; k < windows.length; k++) {
        const end = windows[k].minute_end;
        const start = minuteAt(windows[k].end_row - stride);
        if (m > start && m <= end) return k;
        if (k === 0 && m <= start) return null;
      }
      return null;
    },
    [windows, minuteAt, stride],
  );

  const toLocal = (e: PointerEvent<SVGSVGElement>) => {
    const rect = svgRef.current!.getBoundingClientRect();
    return e.clientX - rect.left;
  };

  const onMove = (e: PointerEvent<SVGSVGElement>) => {
    const px = toLocal(e);
    if (px < padL - 2 || px > width - PAD_R + 2) return setHover(null);
    const row = nearestRow(minutes, x.invert(px));
    setHover({ px: x(minutes[row]), row });
  };

  const onClick = (e: PointerEvent<SVGSVGElement>) => {
    const px = toLocal(e);
    if (px < padL - 2) return;
    const m = x.invert(px);
    const k = cellAtMinute(m);
    if (k !== null) onSelect(k);
    else if (m <= minuteAt(windows[0].end_row - stride)) onSelect(0);
    else onSelect(windows.length - 1);
  };

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const map: Record<string, number> = {
      ArrowLeft: selected - 1,
      ArrowRight: selected + 1,
      PageUp: selected - 5,
      PageDown: selected + 5,
      Home: 0,
      End: windows.length - 1,
    };
    if (e.key in map) {
      e.preventDefault();
      onSelect(map[e.key]);
    }
  };

  const sel = windows[selected];
  const selX0 = x(sel.minute_start);
  const selX1 = x(sel.minute_end);
  const hoverCell = hover ? cellAtMinute(minutes[hover.row]) : null;
  const tipLeft = hover ? (hover.px + 236 > width ? hover.px - 236 : hover.px + 14) : 0;

  return (
    <div
      ref={ref}
      className="relative select-none outline-offset-4"
      tabIndex={0}
      role="group"
      aria-roledescription="时间轴"
      aria-label={`判定时间轴，共 ${windows.length} 个窗口。用左右方向键切换窗口，Home、End 跳到首尾。`}
      onKeyDown={onKey}
    >
      {/* 轨道名 */}
      <span
        className="absolute left-0 text-xs font-semibold text-ink-2"
        style={{ top: L.band.y + L.band.h / 2 - 9 }}
      >
        判定
      </span>
      {L.truth && (
        <span
          className="absolute left-0 text-xs font-semibold text-ink-2"
          style={{ top: L.truth.y + L.truth.h / 2 - 9 }}
        >
          真实
        </span>
      )}
      <span
        className="absolute left-0 text-xs font-semibold text-ink-2"
        style={{ top: L.probs.y + L.probs.h / 2 - 9 }}
      >
        概率
      </span>
      {model.sensors.map((s, i) => {
        const t = L.lanes[i];
        const active = focusedLane === i;
        return (
          <button
            key={s}
            type="button"
            onClick={() => onFocusLane(active ? null : i)}
            aria-pressed={active}
            title={active ? `收起 ${s}` : `放大 ${s}`}
            className={`numeral absolute left-0 flex items-center rounded-sm pr-1 text-left text-sm transition-colors ${
              active ? "text-cobalt" : "text-ink-2 hover:text-ink"
            }`}
            style={{ top: t.y, height: t.h, width: padL - 8 }}
          >
            {s}
          </button>
        );
      })}

      <svg
        ref={svgRef}
        width={width}
        height={L.height}
        className="block cursor-crosshair touch-pan-y"
        onPointerMove={onMove}
        onPointerLeave={() => setHover(null)}
        onPointerUp={onClick}
        aria-hidden
      >
        <defs>
          <pattern
            id="hatch"
            width="6"
            height="6"
            patternUnits="userSpaceOnUse"
            patternTransform="rotate(45)"
          >
            <rect width="6" height="6" fill="var(--surface)" />
            <line x1="0" y1="0" x2="0" y2="6" stroke="var(--hatch)" strokeWidth="2" />
          </pattern>
        </defs>

        {/* 判定色带 */}
        <rect
          x={padL}
          y={L.band.y}
          width={Math.max(0, warmupEnd - padL)}
          height={L.band.h}
          fill="url(#hatch)"
        />
        {warmupEnd - padL > 120 && (
          <text x={padL + 8} y={L.band.y + L.band.h / 2 + 4} fontSize={11} fill="var(--ink-2)">
            基线与首个窗口，尚无判定
          </text>
        )}
        {cells.map(({ x0, x1, w }) => (
          <rect
            key={w.index}
            x={x0}
            y={L.band.y}
            width={Math.max(1, x1 - x0 + 0.5)}
            height={L.band.h}
            fill={classColor(w.pred)}
            fillOpacity={0.22 + 0.78 * Math.max(0, (w.confidence - 1 / 3) / (2 / 3))}
          />
        ))}
        {cells.length > 0 && cells[cells.length - 1].x1 < x.range()[1] - 1 && (
          <rect
            x={cells[cells.length - 1].x1}
            y={L.band.y}
            width={x.range()[1] - cells[cells.length - 1].x1}
            height={L.band.h}
            fill="url(#hatch)"
          />
        )}

        {/* 真实标签 */}
        {L.truth &&
          truth?.segments.map((s) => {
            const x0 = x(minuteAt(s.start_row)) - (s.start_row === 1 ? 0 : 0.5);
            const x1 = x(minuteAt(s.end_row));
            return (
              <rect
                key={`${s.start_row}`}
                x={x0}
                y={L.truth!.y}
                width={Math.max(1, x1 - x0)}
                height={L.truth!.h}
                fill={s.label === null ? "url(#hatch)" : classColor(s.label)}
              />
            );
          })}
        {L.truth &&
          truth?.segments.map((s, i) => {
            const prev = truth.segments[i - 1];
            if (!prev || !s.cut || prev.cut === s.cut || s.label === null) return null;
            const xx = x(minuteAt(s.start_row));
            return (
              <line
                key={`cut-${s.start_row}`}
                x1={xx}
                x2={xx}
                y1={L.truth!.y - 3}
                y2={L.truth!.y + L.truth!.h + 3}
                stroke="var(--ink)"
                strokeWidth={1}
              />
            );
          })}

        {/* 概率堆叠面积 */}
        <rect x={padL} y={L.probs.y} width={x.range()[1] - padL} height={L.probs.h} fill="var(--surface)" />
        {probAreas.map((d, c) => (
          <path key={c} d={d} fill={classColor(c)} fillOpacity={0.85} />
        ))}
        <line
          x1={padL}
          x2={x.range()[1]}
          y1={L.probs.y + L.probs.h / 2}
          y2={L.probs.y + L.probs.h / 2}
          stroke="var(--paper)"
          strokeDasharray="2 3"
          strokeOpacity={0.9}
        />

        {/* 传感器分道 */}
        <rect
          x={padL}
          y={L.lanesTop - 4}
          width={Math.max(0, x(minuteAt(model.baseline_len)) - padL)}
          height={L.lanesBottom - L.lanesTop + 8}
          fill="url(#hatch)"
          opacity={0.6}
        />
        {lanePaths.map((p, i) => {
          const t = L.lanes[i];
          return (
            <g key={i}>
              <line x1={padL} x2={x.range()[1]} y1={t.y + t.h + 1} y2={t.y + t.h + 1} stroke="var(--grid)" />
              {p.zero !== null && p.zero >= t.y && p.zero <= t.y + t.h && (
                <line
                  x1={padL}
                  x2={x.range()[1]}
                  y1={p.zero}
                  y2={p.zero}
                  stroke="var(--rule)"
                  strokeDasharray="1 3"
                />
              )}
              <path
                d={p.d}
                fill="none"
                stroke="var(--ink)"
                strokeWidth={focusedLane === i ? 1.4 : 1}
                strokeLinejoin="round"
              />
              {focusedLane === i &&
                p.y.ticks(4).map((v) => (
                  <text key={v} x={padL + 4} y={p.y(v) - 3} fontSize={10} fill="var(--ink-3)">
                    {laneMode === "relative" ? `${v > 0 ? "+" : ""}${v}%` : v}
                  </text>
                ))}
            </g>
          );
        })}

        {/* 选中窗口 */}
        <rect
          x={selX0}
          y={L.probs.y - 6}
          width={Math.max(1, selX1 - selX0)}
          height={L.lanesBottom - L.probs.y + 10}
          fill="var(--ink)"
          fillOpacity={0.07}
        />
        {[selX0, selX1].map((xx, i) => (
          <line
            key={i}
            x1={xx}
            x2={xx}
            y1={L.probs.y - 6}
            y2={L.lanesBottom + 4}
            stroke="var(--ink)"
            strokeOpacity={0.45}
            strokeDasharray="3 3"
          />
        ))}
        {cells[selected] && (
          <rect
            x={cells[selected].x0 - 1}
            y={L.band.y - 3}
            width={cells[selected].x1 - cells[selected].x0 + 2}
            height={L.band.h + 6}
            fill="none"
            stroke="var(--ink)"
            strokeWidth={2}
          />
        )}

        {/* 横轴 */}
        <line x1={padL} x2={x.range()[1]} y1={L.axisY} y2={L.axisY} stroke="var(--rule)" />
        {ticks.map((t) => (
          <g key={t} transform={`translate(${x(t)},${L.axisY})`}>
            <line y2={4} stroke="var(--rule)" />
            <text y={16} textAnchor="middle" fontSize={11} fill="var(--ink-3)">
              {t}
            </text>
          </g>
        ))}
        <text
          x={x.range()[1]}
          y={L.axisY + 16}
          textAnchor="end"
          fontSize={11}
          fill="var(--ink-3)"
          dx={0}
          dy={0}
        >
          {""}
        </text>

        {/* 悬停游标 */}
        {hover && (
          <line
            x1={hover.px}
            x2={hover.px}
            y1={0}
            y2={L.axisY}
            stroke="var(--focus)"
            strokeWidth={1}
            pointerEvents="none"
          />
        )}
      </svg>

      <p className="pointer-events-none absolute right-3 text-xs text-ink-3" style={{ top: L.axisY + 4 }}>
        分钟
      </p>

      {hover && (
        <div
          className="pointer-events-none absolute z-10 w-[222px] rounded-xl border-2 border-ink bg-surface px-3 py-2 text-xs shadow-[3px_3px_0_var(--ink)]"
          style={{ left: tipLeft, top: L.probs.y }}
        >
          <p className="mb-1 font-semibold text-ink">第 {num(minutes[hover.row])} 分钟</p>
          {hoverCell !== null ? (
            <p className="mb-1.5 text-ink-2">
              判定{" "}
              <span className={`font-semibold ${CLASS_TEXT[windows[hoverCell].pred]}`}>
                {names[windows[hoverCell].pred]}
              </span>{" "}
              <span className="numeral">{pct(windows[hoverCell].confidence)}</span>
            </p>
          ) : (
            <p className="mb-1.5 text-ink-2">
              {hover.row < (windows[0]?.end_row ?? 0) ? "预热段，尚无判定" : "末尾不足一个步长"}
            </p>
          )}
          {truth && truth.labels[hover.row] !== null && (
            <p className="mb-1.5 text-ink-2">
              真实{" "}
              <span className={CLASS_TEXT[truth.labels[hover.row]!]}>{names[truth.labels[hover.row]!]}</span>
            </p>
          )}
          <dl className="grid grid-cols-[auto_1fr_auto_1fr] gap-x-2 gap-y-0.5 border-t border-rule pt-1.5">
            {model.sensors.map((s, i) => (
              <div key={s} className="contents">
                <dt className="text-ink-3">{s}</dt>
                <dd className="numeral text-right text-ink">
                  {laneMode === "relative"
                    ? `${lanesData.transformed[i][hover.row] > 0 ? "+" : ""}${lanesData.transformed[i][hover.row].toFixed(0)}%`
                    : num(series.values[i][hover.row])}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      )}

      <p className="sr-only" aria-live="polite">
        已选中第 {sel.index + 1} 个窗口，第 {num(sel.minute_start)} 到 {num(sel.minute_end)} 分钟，判定为
        {names[sel.pred]}，置信度 {pct(sel.confidence)}。
      </p>
    </div>
  );
});
