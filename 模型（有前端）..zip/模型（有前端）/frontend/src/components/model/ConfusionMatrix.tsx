import { CLASS_TEXT } from "@/lib/classes";

/** 混淆矩阵：格子深浅 = 该真实类别中被判为此类的比例（按行归一化）。 */
export function ConfusionMatrix({ matrix, names }: { matrix: number[][]; names: string[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="border-collapse text-sm">
        <caption className="sr-only">混淆矩阵，行为真实类别，列为预测类别</caption>
        <thead>
          <tr>
            <th scope="col" className="px-2 pb-2 text-left text-xs font-normal text-ink-3">
              真实 ＼ 预测
            </th>
            {names.map((n, c) => (
              <th key={n} scope="col" className={`w-28 px-2 pb-2 text-left font-semibold ${CLASS_TEXT[c]}`}>
                {n}
              </th>
            ))}
            <th scope="col" className="px-2 pb-2 text-right text-xs font-normal text-ink-3">
              合计
            </th>
          </tr>
        </thead>
        <tbody>
          {matrix.map((row, r) => {
            const total = row.reduce((a, b) => a + b, 0);
            return (
              <tr key={r}>
                <th scope="row" className={`px-2 py-0.5 pr-4 text-left font-semibold ${CLASS_TEXT[r]}`}>
                  {names[r]}
                </th>
                {row.map((v, c) => {
                  const share = v / total;
                  return (
                    <td key={c} className="p-0.5">
                      <div
                        className="flex h-16 flex-col justify-between rounded-xl border-2 border-ink px-2.5 py-2"
                        style={{
                          background: `color-mix(in oklab, var(--cobalt) ${Math.round(share * 90)}%, var(--surface))`,
                          color: share > 0.4 ? "#fff" : "var(--ink)",
                        }}
                      >
                        <span className="numeral text-2xl leading-none">{(share * 100).toFixed(0)}%</span>
                        <span className="numeral text-xs opacity-75">{v.toLocaleString("zh-CN")}</span>
                      </div>
                    </td>
                  );
                })}
                <td className="numeral px-2 text-right text-ink-3">{total.toLocaleString("zh-CN")}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
