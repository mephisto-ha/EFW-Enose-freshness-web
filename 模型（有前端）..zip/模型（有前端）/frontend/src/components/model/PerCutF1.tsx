/** 各部位留一 macro-F1 横向条形图，竖线为总体 macro-F1。 */
export function PerCutF1({ data, overall }: { data: { cut: string; f1: number }[]; overall: number }) {
  return (
    <figure>
      <div className="relative space-y-1.5">
        <div
          aria-hidden
          className="absolute bottom-0 top-0 border-l border-dashed border-ink"
          style={{ left: `calc(8.5rem + (100% - 8.5rem - 3rem) * ${overall})` }}
        />
        {data.map((d) => (
          <div key={d.cut} className="grid grid-cols-[8.5rem_1fr_3rem] items-center text-sm">
            <span className="truncate pr-3 text-ink-2">{d.cut.replace(/^\d+\./, "")}</span>
            <span className="h-4 overflow-hidden rounded-full border-2 border-ink bg-grid">
              <span
                className="block h-full bg-ink"
                style={{ width: `${d.f1 * 100}%`, opacity: 0.35 + d.f1 * 0.65 }}
              />
            </span>
            <span className="numeral pl-2 text-right">{d.f1.toFixed(3)}</span>
          </div>
        ))}
      </div>
      <figcaption className="mt-3 text-sm text-ink-2">
        虚线为总体 macro-F1 {overall.toFixed(3)}。每一行都是该部位完全没参与训练时的成绩。
      </figcaption>
    </figure>
  );
}
