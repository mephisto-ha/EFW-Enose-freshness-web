/** 11 路 MQ 传感器各自主要敏感的气体（厂商数据手册口径，简化）。肉类变质主要释放氨、硫化氢、胺类和挥发性有机物。 */
export const SENSOR_GASES: Record<string, string> = {
  MQ135: "氨、苯、空气质量",
  MQ136: "硫化氢",
  MQ137: "氨",
  MQ138: "甲苯、醛类",
  MQ2: "可燃气体、烟雾",
  MQ3: "酒精",
  MQ4: "甲烷",
  MQ5: "天然气、液化气",
  MQ6: "丙烷、丁烷",
  MQ8: "氢气",
  MQ9: "一氧化碳",
};

/** 与变质最相关的通道（氨、硫化氢、醛类），在界面上做重点标记 */
export const SPOILAGE_SENSORS = new Set(["MQ135", "MQ136", "MQ137", "MQ138"]);

/** 贴纸配色：轮换使用，营造极繁的拼贴感 */
export const STICKER_COLORS = [
  "bg-pink text-white",
  "bg-semi text-ink",
  "bg-cobalt text-white",
  "bg-fresh text-white",
  "bg-surface text-ink",
  "bg-tang text-white",
];
