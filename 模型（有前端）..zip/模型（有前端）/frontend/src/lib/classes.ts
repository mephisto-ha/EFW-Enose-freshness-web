/** 类别 → 颜色令牌。类别名以模型元数据为准，顺序固定为 [新鲜, 次新鲜, 腐败]。 */
export const CLASS_VARS = ["var(--fresh)", "var(--semi)", "var(--spoiled)"] as const;

export const CLASS_TEXT = ["text-fresh-ink", "text-semi-ink", "text-spoiled-ink"] as const;
export const CLASS_BG = ["bg-fresh", "bg-semi", "bg-spoiled"] as const;

export function classColor(index: number | null | undefined): string {
  return index === null || index === undefined ? "var(--hatch)" : CLASS_VARS[index];
}
