import meta from "@/data/model-meta.json";

import { EngineError } from "./errors";
import { runBatched, type OrtLike, type OrtSession } from "./ort-runner";
import { decodeText, parseCsvText } from "./parse-table";
import type { AnalyzeRequest, Engine } from "./types";
import { assembleResult, buildInspect, buildTensors, windowEnds, type ModelSpec } from "./windowing";

/**
 * 浏览器内推理：onnxruntime-web（wasm）运行 /models/model.onnx。
 * 运行时由 scripts/copy-ort.mjs 复制到 public/ort/，按需以 <script> 加载，首屏不受影响。
 */

const ORT_SCRIPT = "/ort/ort.wasm.min.js";
const MODEL_URL = "/models/model.onnx";
const SAMPLE_URL = "/samples/sample_beef_input.csv";
const MAX_ROWS = 20000;
const MAX_BYTES = 10 * 1024 * 1024;

export const MODEL_SPEC: ModelSpec = {
  sensors: meta.sensors,
  class_names: meta.class_names,
  win: meta.win,
  baseline_len: meta.baseline_len,
};

declare global {
  interface Window {
    ort?: OrtLike & { env: { wasm: { wasmPaths: string; numThreads: number } } };
  }
}

let ortPromise: Promise<OrtLike> | null = null;
let sessionPromise: Promise<OrtSession> | null = null;

function loadOrt(): Promise<OrtLike> {
  if (ortPromise) return ortPromise;
  ortPromise = new Promise<OrtLike>((resolve, reject) => {
    if (window.ort) return resolve(window.ort);
    const s = document.createElement("script");
    s.src = ORT_SCRIPT;
    s.async = true;
    s.onload = () => {
      const ort = window.ort;
      if (!ort) return reject(new Error("ort missing"));
      ort.env.wasm.wasmPaths = "/ort/";
      // 多线程需要跨源隔离（COOP/COEP）；演示场景单线程已足够快
      ort.env.wasm.numThreads = self.crossOriginIsolated
        ? Math.min(4, navigator.hardwareConcurrency || 1)
        : 1;
      resolve(ort);
    };
    s.onerror = () => reject(new Error("ort load failed"));
    document.head.appendChild(s);
  }).catch((err) => {
    ortPromise = null;
    throw err;
  });
  return ortPromise;
}

async function getSession(ort: OrtLike): Promise<OrtSession> {
  if (!sessionPromise) {
    sessionPromise = (async () => {
      const res = await fetch(MODEL_URL);
      if (!res.ok) throw new Error(`model ${res.status}`);
      return ort.InferenceSession.create(new Uint8Array(await res.arrayBuffer()), {
        executionProviders: ["wasm"],
        graphOptimizationLevel: "all",
      });
    })().catch((err) => {
      sessionPromise = null;
      throw err;
    });
  }
  return sessionPromise;
}

/** 预热：切换到浏览器引擎时提前加载运行时和模型。 */
export async function warmUpBrowserEngine(): Promise<void> {
  const ort = await loadOrt();
  await getSession(ort);
}

async function readSource(source: AnalyzeRequest["source"], signal?: AbortSignal) {
  if (source.kind === "sample") {
    const res = await fetch(SAMPLE_URL, { signal });
    return { buffer: await res.arrayBuffer(), fileName: "sample_beef_input.csv" };
  }
  const fileName = source.file.name;
  if (!/\.(csv|tsv|txt)$/i.test(fileName)) {
    throw new EngineError(
      "UNSUPPORTED_FILE",
      "浏览器引擎只支持 CSV。Excel 文件请切换到「服务器」引擎，或在 Excel 里另存为 CSV。",
    );
  }
  if (source.file.size > MAX_BYTES) throw new EngineError("FILE_TOO_LARGE", "文件超过 10 MB 上限。");
  return { buffer: await source.file.arrayBuffer(), fileName };
}

function parse(buffer: ArrayBuffer) {
  return parseCsvText(decodeText(buffer), {
    sensors: MODEL_SPEC.sensors,
    minRows: MODEL_SPEC.baseline_len + MODEL_SPEC.win,
    maxRows: MAX_ROWS,
  });
}

export const browserEngine: Engine = {
  kind: "browser",
  async inspect({ source, stride, signal }: AnalyzeRequest) {
    const { buffer, fileName } = await readSource(source, signal);
    return buildInspect(parse(buffer), MODEL_SPEC, stride, fileName);
  },
  async analyze({ source, stride, signal }: AnalyzeRequest) {
    const { buffer, fileName } = await readSource(source, signal);
    const t0 = performance.now();
    const table = parse(buffer);
    const ends = windowEnds(table.signals.length, MODEL_SPEC.baseline_len, MODEL_SPEC.win, stride);
    const { windows, baseline } = buildTensors(table.signals, ends, MODEL_SPEC);

    let ort: OrtLike;
    let session: OrtSession;
    try {
      ort = await loadOrt();
      session = await getSession(ort);
    } catch {
      throw new EngineError(
        "BROWSER_ENGINE_UNAVAILABLE",
        "浏览器推理组件加载失败。请刷新页面重试，或切换到「服务器」引擎。",
      );
    }
    if (signal?.aborted) throw new DOMException("aborted", "AbortError");

    const { probs, comp } = await runBatched(ort, session, windows, baseline, {
      B: ends.length,
      win: MODEL_SPEC.win,
      S: MODEL_SPEC.sensors.length,
      baselineLen: MODEL_SPEC.baseline_len,
      C: MODEL_SPEC.class_names.length,
    });

    return assembleResult({
      table,
      spec: MODEL_SPEC,
      stride,
      ends,
      probs,
      compensated: comp,
      fileName,
      elapsedMs: performance.now() - t0,
    });
  },
};
