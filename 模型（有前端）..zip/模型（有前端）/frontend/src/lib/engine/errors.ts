/** 两个引擎共用的错误类型。code 与后端一致，message 直接展示给用户。 */
export class EngineError extends Error {
  readonly code: string;
  readonly detail: Record<string, unknown>;

  constructor(code: string, message: string, detail: Record<string, unknown> = {}) {
    super(message);
    this.name = "EngineError";
    this.code = code;
    this.detail = detail;
  }
}

export function toEngineError(err: unknown): EngineError {
  if (err instanceof EngineError) return err;
  if (err instanceof Error && err.name === "AbortError") {
    return new EngineError("ABORTED", "已取消。");
  }
  return new EngineError("UNKNOWN", "分析失败，请重试。如果问题持续，请换用另一个推理引擎。");
}
