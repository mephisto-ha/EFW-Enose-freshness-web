/** onnxruntime 的最小接口：浏览器里是 window.ort，测试里是 onnxruntime-web 的 Node 模块。 */
export interface OrtTensor {
  data: Float32Array | ArrayLike<number>;
  dims: readonly number[];
}
export interface OrtSession {
  run(feeds: Record<string, OrtTensor>, fetches?: string[]): Promise<Record<string, OrtTensor>>;
}
export interface OrtLike {
  Tensor: new (type: "float32", data: Float32Array, dims: number[]) => OrtTensor;
  InferenceSession: { create(model: ArrayBuffer | Uint8Array | string, opts?: object): Promise<OrtSession> };
}

/** 分批运行，避免一次性申请过大的 wasm 内存。 */
export async function runBatched(
  ort: OrtLike,
  session: OrtSession,
  windows: Float32Array,
  baseline: Float32Array,
  dims: { B: number; win: number; S: number; baselineLen: number; C: number },
  batchSize = 64,
) {
  const { B, win, S, baselineLen, C } = dims;
  const probs = new Float32Array(B * C);
  const comp = new Float32Array(B * win * S);
  const baseTensor = new ort.Tensor("float32", baseline, [baselineLen, S]);
  for (let i = 0; i < B; i += batchSize) {
    const b = Math.min(batchSize, B - i);
    const slice = windows.subarray(i * win * S, (i + b) * win * S);
    const out = await session.run({
      window_raw: new ort.Tensor("float32", new Float32Array(slice), [b, win, S]),
      baseline_raw: baseTensor,
    });
    probs.set(out.probs.data as Float32Array, i * C);
    comp.set(out.compensated_raw.data as Float32Array, i * win * S);
  }
  return { probs, comp };
}
