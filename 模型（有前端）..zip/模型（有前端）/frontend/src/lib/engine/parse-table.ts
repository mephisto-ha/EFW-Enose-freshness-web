import Papa from "papaparse";

import { EngineError } from "./errors";

/** 与 backend/app/parsing.py 规则一致：列名容错、行数校验、数值校验、标签映射。 */

const MINUTE_COLUMNS = ["minute", "minutes", "分钟", "时间(分钟)"];
const LABEL_COLUMNS = ["true_label", "label", "class", "freshness", "真实标签", "标签"];
const CUT_COLUMNS = ["cut", "部位"];

const LABEL_MAP: Record<string, 0 | 1 | 2> = {
  新鲜: 0,
  fresh: 0,
  excellent: 0,
  good: 0,
  次新鲜: 1,
  acceptable: 1,
  "semi-fresh": 1,
  "sub-fresh": 1,
  腐败: 2,
  spoiled: 2,
  spoilage: 2,
  rotten: 2,
};

export interface ParsedTable {
  /** signals[row][sensor] */
  signals: Float32Array[];
  minutes: number[];
  labels: (0 | 1 | 2 | null)[] | null;
  cuts: (string | null)[] | null;
  warnings: string[];
  columns: string[];
  minuteColumn: string | null;
  labelColumn: string | null;
  cutColumn: string | null;
}

export interface ParseOptions {
  sensors: string[];
  minRows: number;
  maxRows: number;
}

/** UTF-8 优先，失败则按 GB18030（Windows Excel 另存的中文 CSV）解码。 */
export function decodeText(buffer: ArrayBuffer): string {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(buffer).replace(/^\uFEFF/, "");
  } catch {
    return new TextDecoder("gb18030").decode(buffer);
  }
}

function findColumn(lookup: Map<string, string>, candidates: string[]): string | null {
  for (const c of candidates) {
    const hit = lookup.get(c.toLowerCase());
    if (hit !== undefined) return hit;
  }
  return null;
}

function toNumber(v: unknown): number {
  if (typeof v === "number") return v;
  if (typeof v !== "string") return NaN;
  const s = v.trim();
  return s === "" ? NaN : Number(s);
}

export function parseCsvText(text: string, opts: ParseOptions): ParsedTable {
  if (!text.trim()) throw new EngineError("EMPTY_FILE", "文件是空的。");
  const parsed = Papa.parse<Record<string, string>>(text, {
    header: true,
    skipEmptyLines: "greedy",
    delimitersToGuess: [",", ";", "\t"],
  });
  const rows = parsed.data;
  const fields = parsed.meta.fields ?? [];
  if (rows.length === 0) throw new EngineError("EMPTY_FILE", "表格里没有数据行。");

  const lookup = new Map<string, string>();
  for (const f of fields) {
    const key = f.trim().toLowerCase();
    if (!lookup.has(key)) lookup.set(key, f);
  }

  const missing = opts.sensors.filter((s) => !lookup.has(s.toLowerCase()));
  if (missing.length) {
    throw new EngineError(
      "MISSING_COLUMNS",
      `缺少传感器列：${missing.join("、")}。表头需要包含全部 ${opts.sensors.length} 个传感器列（${opts.sensors.join("、")}）。`,
      { missing, found: fields },
    );
  }

  const n = rows.length;
  if (n < opts.minRows) {
    throw new EngineError(
      "TOO_FEW_ROWS",
      `数据只有 ${n} 行，至少需要 ${opts.minRows} 行（前 20 行作新鲜基线，再加一个 60 分钟窗口）。`,
      { rows: n, min_rows: opts.minRows },
    );
  }
  if (n > opts.maxRows) {
    throw new EngineError(
      "TOO_MANY_ROWS",
      `数据有 ${n} 行，超过上限 ${opts.maxRows} 行。请拆分文件后分别分析。`,
      { rows: n, max_rows: opts.maxRows },
    );
  }

  const cols = opts.sensors.map((s) => lookup.get(s.toLowerCase()) as string);
  const signals: Float32Array[] = new Array(n);
  let firstBad: { row: number; col: number; raw: string } | null = null;
  let badCount = 0;
  for (let r = 0; r < n; r++) {
    const rec = rows[r];
    const arr = new Float32Array(cols.length);
    for (let c = 0; c < cols.length; c++) {
      const raw = rec[cols[c]];
      const v = toNumber(raw);
      if (!Number.isFinite(v)) {
        badCount++;
        if (!firstBad) firstBad = { row: r, col: c, raw: raw ?? "" };
      }
      arr[c] = v;
    }
    signals[r] = arr;
  }
  if (firstBad) {
    const rowNo = firstBad.row + 1;
    const shown = firstBad.raw.trim() === "" ? "空" : `「${firstBad.raw}」`;
    throw new EngineError(
      "NON_NUMERIC",
      `第 ${rowNo} 行（表格第 ${rowNo + 1} 行）的 ${opts.sensors[firstBad.col]} 列不是有效数字：${shown}。共有 ${badCount} 处这类问题，请补全或删除这些行。`,
      { row: rowNo, column: opts.sensors[firstBad.col], count: badCount },
    );
  }

  const warnings: string[] = [];
  let minutes = Array.from({ length: n }, (_, i) => i + 1);
  const minuteCol = findColumn(lookup, MINUTE_COLUMNS);
  if (minuteCol) {
    const m = rows.map((r) => toNumber(r[minuteCol]));
    const ok = m.every((v, i) => Number.isFinite(v) && (i === 0 || v > m[i - 1]));
    if (ok) minutes = m;
    else warnings.push("「分钟」列缺失值或不是递增的，已改用行号作为时间轴。");
  }

  let labels: ParsedTable["labels"] = null;
  const labelCol = findColumn(lookup, LABEL_COLUMNS);
  if (labelCol) {
    const mapped = rows.map(
      (r) =>
        LABEL_MAP[
          String(r[labelCol] ?? "")
            .trim()
            .toLowerCase()
        ] ?? null,
    );
    if (mapped.some((v) => v !== null)) labels = mapped;
  }

  let cuts: ParsedTable["cuts"] = null;
  const cutCol = findColumn(lookup, CUT_COLUMNS);
  if (cutCol && labels) {
    cuts = rows.map((r) => {
      const v = r[cutCol];
      return v === undefined || v.trim() === "" ? null : v;
    });
  }

  return {
    signals,
    minutes,
    labels,
    cuts,
    warnings,
    columns: fields,
    minuteColumn: minuteCol,
    labelColumn: labels ? labelCol : null,
    cutColumn: cuts ? cutCol : null,
  };
}
