import {
  analysisResultSchema,
  apiErrorSchema,
  healthSchema,
  inspectResultSchema,
  type Health,
} from "../schema";
import { EngineError } from "./errors";
import type { AnalyzeRequest, Engine } from "./types";

/** 通过 Next.js 同源转发 /api/* 到 FastAPI。 */
const API_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "";

async function readError(res: Response): Promise<EngineError> {
  try {
    const body = apiErrorSchema.parse(await res.json());
    return new EngineError(body.error.code, body.error.message, body.error.detail ?? {});
  } catch {
    if (res.status === 413) return new EngineError("FILE_TOO_LARGE", "文件超过 10 MB 上限。");
    if (res.status >= 500) {
      return new EngineError(
        "SERVER_UNAVAILABLE",
        "推理服务暂时不可用。可以切换到「浏览器」引擎继续分析 CSV 文件。",
      );
    }
    return new EngineError("UNKNOWN", `请求失败（HTTP ${res.status}）。`);
  }
}

async function post(path: "analyze" | "inspect", { source, stride, sheet, signal }: AnalyzeRequest) {
  let res: Response;
  try {
    if (source.kind === "sample") {
      res = await fetch(`${API_BASE}/api/${path}/sample?stride=${stride}`, { method: "POST", signal });
    } else {
      const form = new FormData();
      form.append("file", source.file);
      form.append("stride", String(stride));
      if (sheet) form.append("sheet", sheet);
      res = await fetch(`${API_BASE}/api/${path}`, { method: "POST", body: form, signal });
    }
  } catch (err) {
    if (err instanceof Error && err.name === "AbortError") throw err;
    throw new EngineError(
      "SERVER_UNAVAILABLE",
      "连接不上推理服务。请确认后端已启动（端口 8000），或切换到「浏览器」引擎。",
    );
  }
  if (!res.ok) throw await readError(res);
  return res.json();
}

export const serverEngine: Engine = {
  kind: "server",
  async inspect(req: AnalyzeRequest) {
    const parsed = inspectResultSchema.safeParse(await post("inspect", req));
    if (!parsed.success) {
      throw new EngineError("BAD_RESPONSE", "推理服务返回的数据格式与前端不一致，请确认前后端版本匹配。");
    }
    return parsed.data;
  },
  async analyze(req: AnalyzeRequest) {
    const parsed = analysisResultSchema.safeParse(await post("analyze", req));
    if (!parsed.success) {
      throw new EngineError("BAD_RESPONSE", "推理服务返回的数据格式与前端不一致，请确认前后端版本匹配。");
    }
    return parsed.data;
  },
};

export async function fetchHealth(signal?: AbortSignal): Promise<Health | null> {
  try {
    const res = await fetch(`${API_BASE}/api/health`, { signal, cache: "no-store" });
    if (!res.ok) return null;
    return healthSchema.parse(await res.json());
  } catch {
    return null;
  }
}
