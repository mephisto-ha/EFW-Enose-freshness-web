import type { AnalysisResult, InspectResult } from "../schema";

export type EngineKind = "server" | "browser";

export type DataSource = { kind: "sample" } | { kind: "file"; file: File };

export interface AnalyzeRequest {
  source: DataSource;
  stride: number;
  sheet?: string | null;
  signal?: AbortSignal;
}

export interface Engine {
  kind: EngineKind;
  analyze(req: AnalyzeRequest): Promise<AnalysisResult>;
  /** 只解析和校验数据，不跑模型（「数据核验」步骤） */
  inspect(req: AnalyzeRequest): Promise<InspectResult>;
}
