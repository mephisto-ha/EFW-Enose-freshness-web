import type { AnalysisResult, ClassIndex, InspectResult, TruthSegment } from "../schema";
import type { ParsedTable } from "./parse-table";

/** 与 backend/app/analysis.py 一致的滑窗与结果组装逻辑。 */

export interface ModelSpec {
  sensors: string[];
  class_names: string[];
  win: number;
  baseline_len: number;
}

/** 窗口结束行（0 起计）：与参考脚本 np.arange(bl + win - 1, n, stride) 相同。 */
export function windowEnds(nRows: number, baselineLen: number, win: number, stride: number): number[] {
  const ends: number[] = [];
  for (let e = baselineLen + win - 1; e < nRows; e += stride) ends.push(e);
  return ends;
}

/** 打包成模型输入：windows [B, win, S]、baseline [baseline_len, S]，行优先 Float32Array。 */
export function buildTensors(signals: Float32Array[], ends: number[], spec: ModelSpec) {
  const S = spec.sensors.length;
  const windows = new Float32Array(ends.length * spec.win * S);
  ends.forEach((e, b) => {
    for (let t = 0; t < spec.win; t++) {
      windows.set(signals[e - spec.win + 1 + t], (b * spec.win + t) * S);
    }
  });
  const baseline = new Float32Array(spec.baseline_len * S);
  for (let t = 0; t < spec.baseline_len; t++) baseline.set(signals[t], t * S);
  return { windows, baseline };
}

function round(v: number, digits: number): number {
  const f = 10 ** digits;
  return Math.round(v * f) / f;
}

function segments(labels: (ClassIndex | null)[], cuts: (string | null)[] | null): TruthSegment[] {
  const segs: TruthSegment[] = [];
  let start = 0;
  for (let i = 1; i <= labels.length; i++) {
    const boundary =
      i === labels.length || labels[i] !== labels[start] || (cuts !== null && cuts[i] !== cuts[start]);
    if (boundary) {
      segs.push({ start_row: start + 1, end_row: i, label: labels[start], cut: cuts ? cuts[start] : null });
      start = i;
    }
  }
  return segs;
}

export interface AssembleInput {
  table: ParsedTable;
  spec: ModelSpec;
  stride: number;
  ends: number[];
  /** [B * C] 行优先 */
  probs: Float32Array;
  /** [B * win * S] 行优先 */
  compensated: Float32Array | null;
  fileName: string;
  elapsedMs: number;
}

export function assembleResult(input: AssembleInput): AnalysisResult {
  const { table, spec, stride, ends, probs, compensated, fileName, elapsedMs } = input;
  const C = spec.class_names.length;
  const S = spec.sensors.length;
  const n = table.signals.length;
  const mins = table.minutes;
  const labels = table.labels;

  const windows = ends.map((e, k) => {
    const p = Array.from(probs.subarray(k * C, k * C + C));
    let pred = 0;
    for (let c = 1; c < C; c++) if (p[c] > p[pred]) pred = c;
    const s = e - spec.win + 1;
    return {
      index: k,
      start_row: s + 1,
      end_row: e + 1,
      minute_start: mins[s],
      minute_end: mins[e],
      pred: pred as ClassIndex,
      confidence: round(p[pred], 6),
      probs: p.map((v) => round(v, 6)),
      truth: labels ? labels[e] : null,
    };
  });

  const counts = Array.from({ length: C }, (_, c) => windows.filter((w) => w.pred === c).length);
  const first_minute = Array.from(
    { length: C },
    (_, c) => windows.find((w) => w.pred === c)?.minute_end ?? null,
  );

  let agreement: AnalysisResult["summary"]["agreement"] = null;
  if (labels) {
    const scored = windows.filter((w) => w.truth !== null);
    agreement = { matched: scored.filter((w) => w.pred === w.truth).length, total: scored.length };
  }

  let comp: AnalysisResult["compensated"] = null;
  if (compensated) {
    comp = ends.map((_, b) =>
      Array.from({ length: S }, (_, s) =>
        Array.from({ length: spec.win }, (_, t) => round(compensated[(b * spec.win + t) * S + s], 3)),
      ),
    );
  }

  const warnings = [...table.warnings];
  const tail = (n - spec.baseline_len - spec.win) % stride;
  if (tail) warnings.push(`最后 ${tail} 行不足一个步长，未单独生成窗口。`);

  const last = windows[windows.length - 1];
  return {
    source: { file_name: fileName, sheet: null, sheets: [], rows: n, engine: "browser" },
    model: {
      sensors: spec.sensors,
      class_names: spec.class_names,
      win: spec.win,
      baseline_len: spec.baseline_len,
      stride,
    },
    series: {
      minute: mins,
      values: Array.from({ length: S }, (_, s) => table.signals.map((row) => round(row[s], 4))),
    },
    truth: labels ? { labels, segments: segments(labels, table.cuts) } : null,
    windows,
    compensated: comp,
    summary: {
      counts,
      first_minute,
      agreement,
      latest: { pred: last.pred, confidence: last.confidence },
    },
    warnings,
    elapsed_ms: round(elapsedMs, 2),
  };
}

/** 与 backend/app/analysis.py 的 inspect() 一致。 */
export function buildInspect(
  table: ParsedTable,
  spec: ModelSpec,
  stride: number,
  fileName: string,
): InspectResult {
  const n = table.signals.length;
  const mins = table.minutes;
  return {
    file_name: fileName,
    sheet: null,
    sheets: [],
    rows: n,
    columns: table.columns,
    sensors: spec.sensors,
    minute_column: table.minuteColumn,
    label_column: table.labelColumn,
    cut_column: table.cutColumn,
    duration_minutes: mins[n - 1] - mins[0] + 1,
    baseline_len: spec.baseline_len,
    win: spec.win,
    stride,
    n_windows: windowEnds(n, spec.baseline_len, spec.win, stride).length,
    first_judgement_minute: mins[spec.baseline_len + spec.win - 1],
    truth_counts: table.labels
      ? spec.class_names.map((_, c) => table.labels!.filter((v) => v === c).length)
      : null,
    preview: table.signals.slice(0, 5).map((row) => Array.from(row, (v) => round(v, 4))),
    warnings: [...table.warnings],
  };
}
