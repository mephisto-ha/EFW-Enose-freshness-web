import type { AnalysisResult } from "./schema";

/**
 * 导出与 inference_onnx.py 相同字段的 CSV（前 6 列完全一致），后面追加分钟与真实标签。
 * 带 UTF-8 BOM，Excel 直接打开中文不乱码。
 */
export function predictionsCsv(result: AnalysisResult): string {
  const names = result.model.class_names;
  const hasTruth = result.truth !== null;
  const header = [
    "row_end",
    "pred",
    "confidence",
    ...names.map((n) => `p_${n}`),
    "minute_start",
    "minute_end",
    ...(hasTruth ? ["true_label"] : []),
  ];
  const lines = result.windows.map((w) =>
    [
      w.end_row,
      names[w.pred],
      w.confidence.toFixed(4),
      ...w.probs.map((p) => p.toFixed(4)),
      w.minute_start,
      w.minute_end,
      ...(hasTruth ? [w.truth === null ? "" : names[w.truth]] : []),
    ].join(","),
  );
  return "\uFEFF" + [header.join(","), ...lines].join("\r\n") + "\r\n";
}

export function downloadText(text: string, fileName: string, mime = "text/csv;charset=utf-8") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function exportFileName(result: AnalysisResult): string {
  const base = result.source.file_name.replace(/\.[^.]+$/, "");
  const sheet = result.source.sheet ? `_${result.source.sheet}` : "";
  return `${base}${sheet}_predictions.csv`;
}
