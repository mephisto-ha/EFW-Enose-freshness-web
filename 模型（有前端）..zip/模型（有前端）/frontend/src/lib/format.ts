export function pct(v: number, digits = 0): string {
  return `${(v * 100).toFixed(digits)}%`;
}

/** 分钟数显示：整数不带小数；超过 2 小时附带「约 x 小时」。 */
export function minuteLabel(m: number): string {
  const s = Number.isInteger(m) ? String(m) : m.toFixed(1);
  return `第 ${s} 分钟`;
}

export function durationLabel(minutes: number): string {
  if (minutes < 120) return `${Math.round(minutes)} 分钟`;
  const h = minutes / 60;
  return `${Math.round(minutes)} 分钟（约 ${h < 10 ? h.toFixed(1) : Math.round(h)} 小时）`;
}

export function num(v: number, digits = 2): string {
  return Number.isInteger(v) ? String(v) : v.toFixed(digits);
}

export function fileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
