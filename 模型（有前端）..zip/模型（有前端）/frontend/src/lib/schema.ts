import { z } from "zod";

/** 与 backend/app/schemas.py 一一对应。服务器响应在边界处用它校验。 */

const classIndex = z.union([z.literal(0), z.literal(1), z.literal(2)]);

export const analysisResultSchema = z.object({
  source: z.object({
    file_name: z.string(),
    sheet: z.string().nullable(),
    sheets: z.array(z.string()),
    rows: z.number().int(),
    engine: z.enum(["server", "browser"]),
  }),
  model: z.object({
    sensors: z.array(z.string()),
    class_names: z.array(z.string()),
    win: z.number().int(),
    baseline_len: z.number().int(),
    stride: z.number().int(),
  }),
  series: z.object({
    minute: z.array(z.number()),
    values: z.array(z.array(z.number())),
  }),
  truth: z
    .object({
      labels: z.array(classIndex.nullable()),
      segments: z.array(
        z.object({
          start_row: z.number().int(),
          end_row: z.number().int(),
          label: classIndex.nullable(),
          cut: z.string().nullable(),
        }),
      ),
    })
    .nullable(),
  windows: z.array(
    z.object({
      index: z.number().int(),
      start_row: z.number().int(),
      end_row: z.number().int(),
      minute_start: z.number(),
      minute_end: z.number(),
      pred: classIndex,
      confidence: z.number(),
      probs: z.array(z.number()).length(3),
      truth: classIndex.nullable(),
    }),
  ),
  compensated: z.array(z.array(z.array(z.number()))).nullable(),
  summary: z.object({
    counts: z.array(z.number().int()),
    first_minute: z.array(z.number().nullable()),
    agreement: z.object({ matched: z.number().int(), total: z.number().int() }).nullable(),
    latest: z.object({ pred: classIndex, confidence: z.number() }),
  }),
  warnings: z.array(z.string()),
  elapsed_ms: z.number(),
});

export type AnalysisResult = z.infer<typeof analysisResultSchema>;
export type WindowResult = AnalysisResult["windows"][number];
export type ClassIndex = z.infer<typeof classIndex>;
export type TruthSegment = NonNullable<AnalysisResult["truth"]>["segments"][number];

export const apiErrorSchema = z.object({
  error: z.object({
    code: z.string(),
    message: z.string(),
    detail: z.record(z.string(), z.unknown()).optional(),
  }),
});

export const healthSchema = z.object({
  status: z.enum(["ok", "degraded"]),
  model_loaded: z.boolean(),
  version: z.string(),
  onnxruntime: z.string(),
});
export type Health = z.infer<typeof healthSchema>;

export const inspectResultSchema = z.object({
  file_name: z.string(),
  sheet: z.string().nullable(),
  sheets: z.array(z.string()),
  rows: z.number().int(),
  columns: z.array(z.string()),
  sensors: z.array(z.string()),
  minute_column: z.string().nullable(),
  label_column: z.string().nullable(),
  cut_column: z.string().nullable(),
  duration_minutes: z.number(),
  baseline_len: z.number().int(),
  win: z.number().int(),
  stride: z.number().int(),
  n_windows: z.number().int(),
  first_judgement_minute: z.number(),
  truth_counts: z.array(z.number().int()).nullable(),
  preview: z.array(z.array(z.number())),
  warnings: z.array(z.string()),
});
export type InspectResult = z.infer<typeof inspectResultSchema>;
