"use client";

import { create } from "zustand";

import { browserEngine, warmUpBrowserEngine } from "@/lib/engine/browser";
import { EngineError, toEngineError } from "@/lib/engine/errors";
import { fetchHealth, serverEngine } from "@/lib/engine/server";
import type { DataSource, Engine, EngineKind } from "@/lib/engine/types";
import type { AnalysisResult, InspectResult } from "@/lib/schema";

export type ServerStatus = "checking" | "online" | "offline";
export type LaneMode = "raw" | "relative";
export type Step = "submit" | "inspect" | "result";
export const STRIDE_OPTIONS = [5, 10, 20, 30] as const;
const MAX_BYTES = 10 * 1024 * 1024;

interface State {
  step: Step;
  engine: EngineKind;
  serverStatus: ServerStatus;
  source: DataSource | null;
  stride: number;
  sheet: string | null;
  status: "idle" | "loading" | "ready" | "error";
  inspection: InspectResult | null;
  result: AnalysisResult | null;
  error: EngineError | null;
  notice: string | null;
  selected: number;
  laneMode: LaneMode;
  focusedLane: number | null;
}

interface Actions {
  checkServer(): Promise<void>;
  /** 第 1 步 → 第 2 步：提交数据并核验 */
  submit(source: DataSource): Promise<void>;
  /** 第 2 步 → 第 3 步：开始判定 */
  confirm(): Promise<void>;
  back(): void;
  setStride(stride: number): Promise<void>;
  setSheet(sheet: string): Promise<void>;
  setEngine(engine: EngineKind): Promise<void>;
  select(index: number): void;
  stepWindow(delta: number): void;
  setLaneMode(mode: LaneMode): void;
  setFocusedLane(lane: number | null): void;
  dismissNotice(): void;
  reset(): void;
}

let controller: AbortController | null = null;

function isCsvLike(source: DataSource | null): boolean {
  return source !== null && (source.kind === "sample" || /\.(csv|tsv|txt)$/i.test(source.file.name));
}

const engines: Record<EngineKind, Engine> = { server: serverEngine, browser: browserEngine };

export const useWorkspace = create<State & Actions>((set, get) => {
  /** 用当前引擎执行；服务器不可用且数据是 CSV 时自动改走浏览器引擎。 */
  async function run<T>(task: (eng: Engine, signal: AbortSignal) => Promise<T>): Promise<T | undefined> {
    controller?.abort();
    const ctrl = new AbortController();
    controller = ctrl;
    set({ status: "loading", error: null });
    try {
      let out: T;
      try {
        out = await task(engines[get().engine], ctrl.signal);
      } catch (err) {
        const e = toEngineError(err);
        if (get().engine === "server" && e.code === "SERVER_UNAVAILABLE" && isCsvLike(get().source)) {
          set({
            engine: "browser",
            serverStatus: "offline",
            notice: "推理服务没有响应，已改用浏览器推理（结果相同，仅支持 CSV）。",
          });
          out = await task(browserEngine, ctrl.signal);
        } else {
          throw err;
        }
      }
      if (ctrl.signal.aborted) return undefined;
      set({ status: "ready" });
      return out;
    } catch (err) {
      if (!ctrl.signal.aborted) set({ status: "error", error: toEngineError(err) });
      return undefined;
    }
  }

  async function doInspect() {
    const { source, stride, sheet } = get();
    if (!source) return;
    const inspection = await run((eng, signal) => eng.inspect({ source, stride, sheet, signal }));
    if (inspection) set({ inspection, sheet: inspection.sheet, step: "inspect" });
  }

  async function doAnalyze() {
    const { source, stride, sheet } = get();
    if (!source) return;
    const result = await run((eng, signal) => eng.analyze({ source, stride, sheet, signal }));
    if (!result) return;
    const prev = get().result;
    const sameData =
      prev !== null &&
      prev.source.file_name === result.source.file_name &&
      prev.source.sheet === result.source.sheet &&
      prev.model.stride === result.model.stride;
    set({
      result,
      step: "result",
      sheet: result.source.sheet,
      selected: sameData ? Math.min(get().selected, result.windows.length - 1) : result.windows.length - 1,
    });
  }

  return {
    step: "submit",
    engine: "server",
    serverStatus: "checking",
    source: null,
    stride: 10,
    sheet: null,
    status: "idle",
    inspection: null,
    result: null,
    error: null,
    notice: null,
    selected: 0,
    laneMode: "raw",
    focusedLane: null,

    async checkServer() {
      const health = await fetchHealth();
      const online = health?.model_loaded === true;
      set({ serverStatus: online ? "online" : "offline" });
      if (!online && get().engine === "server") {
        set({ engine: "browser", notice: "没有连上推理服务，已改用浏览器推理（结果相同，仅支持 CSV）。" });
        warmUpBrowserEngine().catch(() => undefined);
      }
    },

    async submit(source) {
      if (source.kind === "file" && source.file.size > MAX_BYTES) {
        set({
          status: "error",
          error: new EngineError("FILE_TOO_LARGE", "文件超过 10 MB 上限。请拆分后分别分析。"),
        });
        return;
      }
      set({ source, sheet: null, result: null, inspection: null, focusedLane: null });
      await doInspect();
    },

    async confirm() {
      await doAnalyze();
    },

    back() {
      controller?.abort();
      const { step } = get();
      set({ status: "ready", error: null, step: step === "result" ? "inspect" : "submit" });
    },

    async setStride(stride) {
      set({ stride });
      if (get().step === "result") await doAnalyze();
      else if (get().step === "inspect") await doInspect();
    },

    async setSheet(sheet) {
      set({ sheet });
      if (get().step === "result") await doAnalyze();
      else await doInspect();
    },

    async setEngine(engine) {
      if (engine === get().engine) return;
      if (engine === "server") {
        const health = await fetchHealth();
        if (!health?.model_loaded) {
          set({
            serverStatus: "offline",
            notice: "推理服务仍未连接，继续使用浏览器推理。请确认后端已在 8000 端口启动。",
          });
          return;
        }
        set({ serverStatus: "online" });
      }
      set({ engine, notice: null });
      if (engine === "browser") warmUpBrowserEngine().catch(() => undefined);
      if (engine === "browser" && get().source && !isCsvLike(get().source)) {
        set({
          status: "error",
          error: new EngineError(
            "UNSUPPORTED_FILE",
            "浏览器引擎只支持 CSV。Excel 文件请切回「服务器」引擎，或在 Excel 里另存为 CSV。",
          ),
        });
        return;
      }
      if (get().step === "result") await doAnalyze();
      else if (get().step === "inspect") await doInspect();
    },

    select(index) {
      const n = get().result?.windows.length ?? 0;
      if (n === 0) return;
      set({ selected: Math.max(0, Math.min(n - 1, index)) });
    },

    stepWindow(delta) {
      get().select(get().selected + delta);
    },

    setLaneMode(laneMode) {
      set({ laneMode });
    },

    setFocusedLane(focusedLane) {
      set({ focusedLane });
    },

    dismissNotice() {
      set({ notice: null });
    },

    reset() {
      controller?.abort();
      set({
        step: "submit",
        source: null,
        result: null,
        inspection: null,
        status: "idle",
        error: null,
        sheet: null,
        focusedLane: null,
      });
    },
  };
});
