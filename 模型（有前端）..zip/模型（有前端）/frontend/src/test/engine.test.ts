import { readFileSync } from "node:fs";
import { join } from "node:path";

import * as ort from "onnxruntime-web";
import { describe, expect, it } from "vitest";

import { MODEL_SPEC } from "@/lib/engine/browser";
import { EngineError } from "@/lib/engine/errors";
import { runBatched, type OrtLike } from "@/lib/engine/ort-runner";
import { decodeText, parseCsvText } from "@/lib/engine/parse-table";
import { assembleResult, buildInspect, buildTensors, windowEnds } from "@/lib/engine/windowing";
import { analysisResultSchema, inspectResultSchema } from "@/lib/schema";

const root = join(__dirname, "..", "..");
const fixtures = join(__dirname, "fixtures");
const sampleBuf = readFileSync(join(root, "public", "samples", "sample_beef_input.csv"));
const opts = { sensors: MODEL_SPEC.sensors, minRows: 80, maxRows: 20000 };

function toArrayBuffer(b: Buffer): ArrayBuffer {
  return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) as ArrayBuffer;
}

async function runBrowserPipeline(stride = 10) {
  const table = parseCsvText(decodeText(toArrayBuffer(sampleBuf)), opts);
  const ends = windowEnds(table.signals.length, 20, 60, stride);
  const { windows, baseline } = buildTensors(table.signals, ends, MODEL_SPEC);
  ort.env.wasm.numThreads = 1;
  const session = await ort.InferenceSession.create(
    new Uint8Array(readFileSync(join(root, "public", "models", "model.onnx"))),
  );
  const { probs, comp } = await runBatched(ort as unknown as OrtLike, session as never, windows, baseline, {
    B: ends.length,
    win: 60,
    S: 11,
    baselineLen: 20,
    C: 3,
  });
  return assembleResult({
    table,
    spec: MODEL_SPEC,
    stride,
    ends,
    probs,
    compensated: comp,
    fileName: "s.csv",
    elapsedMs: 0,
  });
}

describe("windowing", () => {
  it("与参考脚本相同的窗口结束行", () => {
    const ends = windowEnds(380, 20, 60, 10);
    expect(ends.length).toBe(31);
    expect(ends[0] + 1).toBe(80);
    expect(ends.at(-1)! + 1).toBe(380);
  });
});

describe("parseCsvText", () => {
  it("识别真实标签和部位", () => {
    const t = parseCsvText(decodeText(toArrayBuffer(sampleBuf)), opts);
    expect(t.signals.length).toBe(380);
    expect(t.labels?.[0]).toBeNull();
    expect(t.labels?.[379]).toBe(2);
    expect(t.cuts?.[379]).toBe("7.Rib_eye");
  });

  it("缺列时报出具体列名", () => {
    const text = decodeText(toArrayBuffer(sampleBuf)).replace("MQ9,", "XX9,");
    expect(() => parseCsvText(text, opts)).toThrowError(EngineError);
    try {
      parseCsvText(text, opts);
    } catch (e) {
      expect((e as EngineError).code).toBe("MISSING_COLUMNS");
      expect((e as EngineError).detail.missing).toEqual(["MQ9"]);
    }
  });

  it("非数字报出行号", () => {
    const lines = decodeText(toArrayBuffer(sampleBuf)).split(/\r?\n/);
    const cells = lines[100].split(",");
    cells[7] = "err"; // MQ4
    lines[100] = cells.join(",");
    try {
      parseCsvText(lines.join("\n"), opts);
      expect.unreachable();
    } catch (e) {
      expect((e as EngineError).code).toBe("NON_NUMERIC");
      expect((e as EngineError).detail).toEqual({ row: 100, column: "MQ4", count: 1 });
    }
  });

  it("GB18030 编码可读", () => {
    const gbk = new TextEncoder().encode("新鲜");
    expect(decodeText(gbk.buffer as ArrayBuffer)).toBe("新鲜");
  });
});

describe("服务器响应契约", () => {
  it("后端真实响应通过前端 zod 校验", () => {
    const body = JSON.parse(readFileSync(join(fixtures, "sample-analysis.server.json"), "utf-8"));
    const parsed = analysisResultSchema.parse(body);
    expect(parsed.windows.length).toBe(31);
  });

  it("前端内置的指标与后端一致", () => {
    const fe = JSON.parse(readFileSync(join(root, "src", "data", "metrics.json"), "utf-8"));
    const be = JSON.parse(
      readFileSync(join(root, "..", "backend", "assets", "model_beef", "metrics.json"), "utf-8"),
    );
    expect(fe).toEqual(be);
  });
});

describe("浏览器引擎一致性", () => {
  it("与 sample_predictions.csv（参考脚本实测）逐项一致", async () => {
    const result = await runBrowserPipeline();
    const ref = readFileSync(join(fixtures, "sample_predictions.csv"), "utf-8")
      .replace(/^\uFEFF/, "")
      .trim()
      .split(/\r?\n/)
      .slice(1)
      .map((l) => l.split(","));
    expect(result.windows.length).toBe(ref.length);
    result.windows.forEach((w, i) => {
      const [rowEnd, pred, conf, p0, p1, p2] = ref[i];
      expect(w.end_row).toBe(Number(rowEnd));
      expect(MODEL_SPEC.class_names[w.pred]).toBe(pred);
      expect(Math.abs(w.confidence - Number(conf))).toBeLessThan(1e-3);
      [p0, p1, p2].forEach((p, c) => expect(Math.abs(w.probs[c] - Number(p))).toBeLessThan(1e-3));
    });
  });

  it("与服务器引擎结果一致（含漂移补偿与摘要）", async () => {
    const browser = await runBrowserPipeline();
    const server = analysisResultSchema.parse(
      JSON.parse(readFileSync(join(fixtures, "sample-analysis.server.json"), "utf-8")),
    );
    expect(analysisResultSchema.parse(browser)).toBeTruthy();
    expect(browser.summary.counts).toEqual(server.summary.counts);
    expect(browser.summary.first_minute).toEqual(server.summary.first_minute);
    expect(browser.summary.agreement).toEqual(server.summary.agreement);
    expect(browser.truth?.segments).toEqual(server.truth?.segments);
    let maxDiff = 0;
    browser.compensated!.forEach((w, b) =>
      w.forEach((s, j) =>
        s.forEach((v, t) => (maxDiff = Math.max(maxDiff, Math.abs(v - server.compensated![b][j][t])))),
      ),
    );
    expect(maxDiff).toBeLessThan(0.01);
  });
});

describe("数据核验", () => {
  it("浏览器端核验结果与服务器 /api/inspect 一致", () => {
    const table = parseCsvText(decodeText(toArrayBuffer(sampleBuf)), opts);
    const browser = buildInspect(table, MODEL_SPEC, 10, "sample_beef_input.csv");
    const server = inspectResultSchema.parse(
      JSON.parse(readFileSync(join(fixtures, "sample-inspect.server.json"), "utf-8")),
    );
    expect(inspectResultSchema.parse(browser)).toEqual(server);
  });

  it("从 Excel 复制的制表符分隔文本可以解析", () => {
    const tsv = decodeText(toArrayBuffer(sampleBuf)).replace(/,/g, "\t");
    const t = parseCsvText(tsv, opts);
    expect(t.signals.length).toBe(380);
    expect(t.labelColumn).toBe("true_label");
  });
});
