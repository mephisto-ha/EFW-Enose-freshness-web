"""独立推理脚本：只依赖 numpy、pandas、openpyxl、onnxruntime，不需要 PyTorch 和本项目代码。
  pip install -r requirements_inference.txt
  python inference_onnx.py --data 你的数据.xlsx [--sheet 工作表名]
输入表格需包含 model_meta.json 中 sensors 列出的 11 个传感器列，每行一分钟；前 baseline_len 行视为开始监测时的新鲜基线。
"""
import argparse
import json
import os

import numpy as np
import onnxruntime as ort
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default=os.path.join(HERE, "model_beef", "model.onnx"))
    p.add_argument("--meta", default=os.path.join(HERE, "model_beef", "model_meta.json"))
    p.add_argument("--data", required=True)
    p.add_argument("--sheet", default=None)
    p.add_argument("--stride", type=int, default=10)
    p.add_argument("--out", default="predictions.csv")
    a = p.parse_args()
    meta = json.load(open(a.meta, encoding="utf-8"))
    win, bl, sensors, names = meta["win"], meta["baseline_len"], meta["sensors"], meta["class_names"]
    if a.data.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(a.data, sheet_name=a.sheet if a.sheet else 0)
    else:
        df = pd.read_csv(a.data)
    sig = df[sensors].to_numpy(np.float32)
    if len(sig) < bl + win:
        raise SystemExit(f"数据只有 {len(sig)} 行，至少需要 {bl + win} 行")
    ends = np.arange(bl + win - 1, len(sig), a.stride)
    windows = np.stack([sig[e - win + 1:e + 1] for e in ends]).astype(np.float32)
    sess = ort.InferenceSession(a.model, providers=["CPUExecutionProvider"])
    probs, _ = sess.run(None, {"window_raw": windows, "baseline_raw": sig[:bl]})
    out = pd.DataFrame({"row_end": ends + 1, "pred": [names[i] for i in probs.argmax(1)],
                        "confidence": probs.max(1).round(4)})
    for i, n in enumerate(names):
        out[f"p_{n}"] = probs[:, i].round(4)
    out.to_csv(a.out, index=False, encoding="utf-8-sig")
    print(out.tail(10).to_string(index=False))
    print(f"\n共 {len(out)} 个窗口，结果已保存：{a.out}")


if __name__ == "__main__":
    main()
